package it.unimib.spendaciun.data.source.categoria;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import it.unimib.spendaciun.model.categoria.CategoriaSpesa;

public class RemoteCategoriaSpesaDataSource {

    private static final String TAG = "RemoteCategoriaSpesaDS";
    private FirebaseFirestore db;

    public RemoteCategoriaSpesaDataSource() {
        db = FirebaseFirestore.getInstance();
    }

    public void addCategoria(CategoriaSpesa categoria) {
        if (categoria.getId() == null || categoria.getId().isEmpty()) {
            categoria.setId(UUID.randomUUID().toString());
        }
        categoria.setAuthId(FirebaseAuth.getInstance().getCurrentUser().getUid());

        db.collection("categorie").document(categoria.getId())
                .set(categoria)
                .addOnSuccessListener(aVoid -> Log.d(TAG, "Categoria added successfully"))
                .addOnFailureListener(e -> Log.w(TAG, "Error adding categoria", e));
    }

    public LiveData<List<CategoriaSpesa>> getCategorie() {
        MutableLiveData<List<CategoriaSpesa>> liveDataCategorie = new MutableLiveData<>();
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        db.collection("categorie").whereEqualTo("authId", userId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<CategoriaSpesa> categorieList = new ArrayList<>();
                        for (DocumentSnapshot document : task.getResult()) {
                            CategoriaSpesa categoria = document.toObject(CategoriaSpesa.class);
                            categorieList.add(categoria);
                        }
                        liveDataCategorie.setValue(categorieList);
                    } else {
                        Log.w(TAG, "Error getting categories", task.getException());
                    }
                });

        return liveDataCategorie;
    }

    public void deleteCategoria(String categoriaId) {
        db.collection("categorie").document(categoriaId)
                .delete()
                .addOnSuccessListener(aVoid -> Log.d(TAG, "Categoria deleted successfully"))
                .addOnFailureListener(e -> Log.w(TAG, "Error deleting categoria", e));
    }

    public Task<Void> deleteAllCategorie() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        return db.collection("categorie").whereEqualTo("authId", userId)
                .get()
                .continueWithTask(task -> {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }

                    List<Task<Void>> deleteTasks = new ArrayList<>();
                    for (DocumentSnapshot document : task.getResult()) {
                        Task<Void> deleteTask = db.collection("categorie").document(document.getId()).delete();
                        deleteTasks.add(deleteTask);
                    }
                    return Tasks.whenAll(deleteTasks);
                });
    }

    public void addDefaultCategories() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String tipoEntrata = "Entrata";
        String tipoUscita = "Uscita";

        List<String> defaultCategorieEntrate = Arrays.asList("Stipendio", "Vendite", "Rimborsi", "Regali", "Premi", "Investimenti", "Pensione", "Entrate Extra");
        for (String nomeCategoria : defaultCategorieEntrate) {
            CategoriaSpesa categoria = new CategoriaSpesa(nomeCategoria, tipoEntrata);
            addCategoria(categoria);
        }

        List<String> defaultCategorieUscite = Arrays.asList("Alimentari", "Abitazione", "Trasporti", "Intrattenimento", "Educazione", "Salute", "Abbigliamento", "Bollette");
        for (String nomeCategoria : defaultCategorieUscite) {
            CategoriaSpesa categoria = new CategoriaSpesa(nomeCategoria, tipoUscita);
            addCategoria(categoria);
        }
    }
}
