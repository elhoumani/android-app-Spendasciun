package it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import it.unimib.spendaciun.data.repository.categoria.CategoriaSpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.spesa.SpesaRepository;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;

public class CategoriaManagerViewModel extends ViewModel {
        private CategoriaSpesaFirestoreRepository mRepo;

        public CategoriaManagerViewModel() {
            super();
            mRepo = new CategoriaSpesaFirestoreRepository();
        }

    public LiveData<List<CategoriaSpesa>> getCategorie() {
            return mRepo.getCategorie();
    }

    public void deleteCategoria(String tmp) {
            mRepo.deleteCategoria(tmp);
    }

    public void addCategoria(CategoriaSpesa nuovaCategoria) {
            mRepo.addCategoria(nuovaCategoria);
    }
}
