package it.unimib.spendaciun.ui.main.fragment.scanner;

import static android.app.Activity.RESULT_OK;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.snackbar.Snackbar;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.ui.shared.SharedViewModel;
import it.unimib.spendaciun.util.dialog.AddExpenseDialogFragment;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScannerFragment extends Fragment {

    private ScannerViewModel viewModel;
    private ImageView scannerImageView;
    private Button openCameraButton, openGalleryButton;
    private TextView resultTextView;
    private ProgressBar progressBar;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_scanner, container, false);
        viewModel = new ViewModelProvider(this).get(ScannerViewModel.class);

        scannerImageView = view.findViewById(R.id.scannerImageView);
        resultTextView = view.findViewById(R.id.resultTextView);
        openCameraButton = view.findViewById(R.id.openCameraButton);
        openGalleryButton = view.findViewById(R.id.openGalleryButton);
        Button btnAddToExpenses = view.findViewById(R.id.btnAddToExpenses);
        progressBar = view.findViewById(R.id.scannerProgressBar);

        openCameraButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                viewModel.launchCamera(cameraResultLauncher);
            } else {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA);
            }
        });

        openGalleryButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                viewModel.launchGallery(galleryResultLauncher);
            } else {
                requestStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        });

        ScannerViewModel viewModel = new ViewModelProvider(this).get(ScannerViewModel.class);
        SharedViewModel sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        viewModel.setSharedViewModel(sharedViewModel);

        btnAddToExpenses.setOnClickListener(v -> {
            LiveData<String> recognizedAmount = sharedViewModel.getRecognizedAmount();
            LiveData<String> recognizedDate = sharedViewModel.getRecognizedDate();

            if ((recognizedAmount.getValue() != null && !"Importo non trovato".equals(recognizedAmount.getValue()))
                    || (recognizedDate.getValue() != null && !"Data non trovata".equals(recognizedDate.getValue()))) {
                AddExpenseDialogFragment dialogFragment = new AddExpenseDialogFragment(recognizedAmount.getValue(), recognizedDate.getValue());
                dialogFragment.show(getParentFragmentManager(), "AddExpenseDialogFragment");
            } else {
                Snackbar.make(view, R.string.scattare_caricare, Snackbar.LENGTH_LONG).show();

            }
        });


        return view;
    }

    private final ActivityResultLauncher<Intent> cameraResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK) {
                        Uri imageUri = viewModel.getImageUri().getValue();
                        scannerImageView.setImageURI(imageUri);
                        processImage(imageUri);
                    }
                }
            }
    );

    private final ActivityResultLauncher<Intent> galleryResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri imageUri = result.getData().getData();
                        scannerImageView.setImageURI(imageUri);
                        processImage(imageUri);
                    }
                }
            }
    );

    private final ActivityResultLauncher<String> requestCameraPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    viewModel.launchCamera(cameraResultLauncher);
                } else {
                    showPermissionDeniedSnackbar();
                }
            });

    private final ActivityResultLauncher<String> requestStoragePermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    viewModel.launchGallery(galleryResultLauncher);
                } else {
                    showPermissionDeniedSnackbar();
                }
            });



    private void processImage(Uri imageUri) {
        progressBar.setVisibility(View.VISIBLE);

        try {
            InputImage image = InputImage.fromFilePath(requireContext(), imageUri);
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                    .addOnSuccessListener(visionText -> {
                        String rawText = visionText.getText();

                        String amountPattern = "(EUR|EURO|€|TOTALE COMPLESSIVO)\\s*\\d{1,3}(?:[.,]\\d{2})?";
                        String datePattern = "\\d{2}[-/.]\\d{2}[-/.]\\d{4}";
                        Pattern patternAmount = Pattern.compile(amountPattern);
                        Pattern patternDate = Pattern.compile(datePattern);

                        Matcher matcherAmount = patternAmount.matcher(rawText);
                        Matcher matcherDate = patternDate.matcher(rawText);

                        String foundAmount = matcherAmount.find() ? matcherAmount.group() : "Importo non trovato";
                        String foundDate = matcherDate.find() ? matcherDate.group() : "Data non trovata";

                        String result = "Data :  " + foundDate + "\nImporto :  " + foundAmount;
                        resultTextView.setText(result);

                        if (!"Importo non trovato".equals(foundAmount) || !"Data non trovata".equals(foundDate)) {
                            SharedViewModel sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

                            sharedViewModel.setRecognizedAmount(foundAmount.replaceAll("EUR\\s*", ""));
                            if (!"Data non trovata".equals(foundDate)) {
                                String formattedDate = foundDate.replace('.', '/').replace('-', '/');
                                sharedViewModel.setRecognizedDate(formattedDate);
                            }
                        }

                        progressBar.setVisibility(View.GONE);
                    })
                    .addOnFailureListener(e -> {
                        progressBar.setVisibility(View.GONE);
                    });
        } catch (IOException e) {
            e.printStackTrace();
            progressBar.setVisibility(View.GONE);
        }

    }
    private void showPermissionDeniedSnackbar() {
        Snackbar.make(requireView(), R.string.permesso_negato, Snackbar.LENGTH_LONG).show();
    }
}