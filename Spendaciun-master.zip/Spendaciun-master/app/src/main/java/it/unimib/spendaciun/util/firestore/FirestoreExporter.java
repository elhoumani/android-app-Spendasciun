package it.unimib.spendaciun.util.firestore;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.opencsv.CSVWriter;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.databinding.FragmentAggiungispesaBinding;
import it.unimib.spendaciun.model.spesa.Spesa;
import it.unimib.spendaciun.ui.main.fragment.aggiungiSpesa.AggiungiSpesaViewModel;
import it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni.ProfileViewModel;

public class FirestoreExporter {

    private static final String TAG = "FirestoreExporter";
    private static ExporterViewModel mViewModel;

    public FirestoreExporter(){
        mViewModel = new ExporterViewModel();
    }


    public static void exportToCSV(Context context, String authId) {
        List<Spesa> expenses = mViewModel.exportToCSV(authId);
        Collections.sort(expenses, (spesa1, spesa2) -> spesa2.getData().compareTo(spesa1.getData()));
        saveToCSV(context, expenses);
}

    private static void saveToCSV(Context context, List<Spesa> expenses) {
        String fileName = "spese.csv";

        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, "text/csv");
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

        Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);

        try (CSVWriter csvWriter = new CSVWriter(new OutputStreamWriter(context.getContentResolver().openOutputStream(uri)))) {
            csvWriter.writeNext(new String[]{"ID", "Nome", "Importo", "Data", "Categoria", "TipoSpesa"});

            for (Spesa spesa : expenses) {
                String[] row = {
                        spesa.getId(), spesa.getNome(), String.valueOf(spesa.getImporto()),
                        dateToString(spesa.getData()), spesa.getCategoria(), spesa.getTipoSpesa()
                };
                csvWriter.writeNext(row);
            }
            Log.d(TAG, "CSV salvato con successo: " + uri.toString());
        } catch (IOException e) {
            Log.e(TAG, "Errore durante il salvataggio del CSV", e);
        }
    }

    private static String dateToString(Date date) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateFormat.format(date);
    }
}
