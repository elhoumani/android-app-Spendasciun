package it.unimib.spendaciun.model.spesa;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.google.firebase.auth.FirebaseAuth;

import org.jetbrains.annotations.NotNull;

import java.util.Date;

@Entity(tableName = "spesa_table")
public class Spesa {

    @NotNull
    @PrimaryKey
    @ColumnInfo(name = "id")
    private String id;
    private String authId;
    private String nome;
    private double importo;
    private Date data;
    private String categoria;
    private String tipoSpesa;

    public Spesa() {}

    @Ignore
    public Spesa(String id, String authId, String nome, double importo, Date data, String categoria, String tipoSpesa) {
        this.id = id;
        this.authId = authId;
        this.nome = nome;
        this.importo = importo;
        this.data = data;
        this.categoria = categoria;
        this.tipoSpesa = tipoSpesa;
    }

    @Ignore
    public Spesa(String authId, String nome, double importo, Date data, String categoria, String tipoSpesa) {
        this(null, authId, nome, importo, data, categoria, tipoSpesa);
    }

    @Ignore
    public Spesa(String authId, String nome, double importo) {
        this(authId, nome, importo, new Date(), "", "");
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAuthId() {
        return authId;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public double getImporto() {
        return importo;
    }

    public void setImporto(double importo) {
        this.importo = importo;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getTipoSpesa() {
        return tipoSpesa;
    }

    public void setTipoSpesa(String tipoSpesa) {
        this.tipoSpesa = tipoSpesa;
    }
}
