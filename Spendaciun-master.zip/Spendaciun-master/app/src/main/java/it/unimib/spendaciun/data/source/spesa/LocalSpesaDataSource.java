package it.unimib.spendaciun.data.source.spesa;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import it.unimib.spendaciun.data.database.spesa.SpesaDao;
import it.unimib.spendaciun.model.spesa.Spesa;

public class LocalSpesaDataSource {

    private SpesaDao spesaDao;
    private Executor executor;

    public LocalSpesaDataSource(SpesaDao spesaDao) {
        this.spesaDao = spesaDao;
        this.executor = Executors.newSingleThreadExecutor();
    }




    public void insertSpesa(Spesa spesa) {
        executor.execute(() -> spesaDao.insert(spesa));
    }

    public void updateSpesa(Spesa spesa) {
        executor.execute(() -> spesaDao.update(spesa));
    }

    public void deleteSpesa(Spesa spesa) {
        executor.execute(() -> spesaDao.delete(spesa));
    }

    public void deleteByUserId(String userId) {
        executor.execute(() -> spesaDao.deleteByUserId(userId));
    }

    public void deleteByItemId(String itemId) {
        executor.execute(() -> spesaDao.deleteByItemId(itemId));
    }

    public void deleteAll() {
        executor.execute(spesaDao::deleteAll);
    }


    public LiveData<List<Spesa>> getSpeseUtente(String userId) {
        return spesaDao.getSpeseUtente(userId);
    }

}

