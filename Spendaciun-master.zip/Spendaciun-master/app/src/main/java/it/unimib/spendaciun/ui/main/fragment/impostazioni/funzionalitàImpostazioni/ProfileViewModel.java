package it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseUser;

import java.util.Map;
import java.util.function.Consumer;

import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.spesa.SpesaRepository;
import it.unimib.spendaciun.data.repository.user.UserRepository;

public class ProfileViewModel extends ViewModel {
    private UserRepository mUserRepo;
    public ProfileViewModel() {
            mUserRepo = new UserRepository();
        }
    public FirebaseUser getCurretUser() {
        return mUserRepo.getCurretUser();
    }

    public void loadUserInformation(String userId, Consumer<Map<String, Object>> onSuccess) {
        mUserRepo.loadUserInformation(userId, onSuccess);
    }

    public void updateUserName(String uid, String newName) {
        mUserRepo.updateUserName(uid, newName);
    }
}
