package it.unimib.spendaciun.data.source.spesa;

import android.util.Log;

import androidx.core.util.Consumer;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import it.unimib.spendaciun.model.spesa.Spesa;

public class RemoteSpesaDataSource {

    private static final String TAG = "RemoteSpesaDataSource";
    private FirebaseFirestore db;
    private String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

    public RemoteSpesaDataSource() {
        db = FirebaseFirestore.getInstance();
    }


    public String getCurrentAuthId(){
        return userId;
    }

    public void addSpesa(Spesa spesa) {
        if (spesa.getId() == null) {
            spesa.setId(UUID.randomUUID().toString());
        }
        if(spesa.getAuthId() == null){
            spesa.setAuthId( userId);

        }

        db.collection("spese").document(spesa.getId())
                .set(spesa)
                .addOnSuccessListener(aVoid -> Log.d(TAG, "DocumentSnapshot successfully written!"))
                .addOnFailureListener(e -> Log.w(TAG, "Error writing document", e));
    }

    public LiveData<List<Spesa>> getSpese() {
        MutableLiveData<List<Spesa>> liveDataSpese = new MutableLiveData<>();
        db.collection("spese").whereEqualTo("authId", userId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<Spesa> spesaList = new ArrayList<>();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Spesa spesa = document.toObject(Spesa.class);
                            spesaList.add(spesa);
                        }
                        liveDataSpese.setValue(spesaList);
                    } else {
                        Log.w(TAG, "Error getting documents.", task.getException());
                    }
                });
        return liveDataSpese;
    }

    public void deleteSpesa(String spesaId) {
        db.collection("spese").document(spesaId)
                .delete()
                .addOnSuccessListener(aVoid -> Log.d(TAG, "DocumentSnapshot successfully deleted!"))
                .addOnFailureListener(e -> Log.w(TAG, "Error deleting document", e));
    }

    public Task<Void> deleteAll(String userId) {
        return db.collection("spese").whereEqualTo("authId", userId)
                .get()
                .continueWithTask(task -> {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                    List<Task<Void>> deleteTasks = new ArrayList<>();
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Task<Void> deleteTask = db.collection("spese").document(document.getId()).delete();
                        deleteTasks.add(deleteTask);
                    }
                    return Tasks.whenAll(deleteTasks);
                });
    }


    public LiveData<List<String>> getCategorieUtente(
            String authId, String tipoSpesa, List<String> selectedCategories, Date startDate, Date endDate) {
        if(authId == null){
            authId = userId;
        }

        MutableLiveData<List<String>> categorieLiveData = new MutableLiveData<>();

        Query query = db.collection("spese")
                .whereEqualTo("authId", authId)
                .whereEqualTo("tipoSpesa", tipoSpesa);

        if (startDate != null && endDate != null) {
            query = query
                    .whereGreaterThanOrEqualTo("data", getTimestampFromDate(startDate))
                    .whereLessThanOrEqualTo("data", getTimestampFromDate(endDate));
        }

        if (selectedCategories != null && !selectedCategories.isEmpty()) {
            query = query.whereIn("categoria", selectedCategories);
        }

        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                List<String> categorieList = new ArrayList<>();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    String categoria = document.getString("categoria");
                    if (categoria != null && !categorieList.contains(categoria)) {
                        categorieList.add(categoria);
                    }
                }
                categorieLiveData.setValue(categorieList);
                Log.d("CATEGORIE", "Categorie: " + categorieList);
            } else {
                // Gestisci l'errore se la query non è riuscita
                Log.e("GraficiRepository", "Errore nella query getCategorieUtente", task.getException());
                categorieLiveData.setValue(Collections.emptyList());
            }
        });

        return categorieLiveData;
    }

    public LiveData<List<Float>> getTotaleCategorie(String authId, String tipoSpesa, List<String> selectedCategories, Date startDate, Date endDate) {
        LiveData<List<String>> categorieLiveData = getCategorieUtente(authId, tipoSpesa, selectedCategories, startDate, endDate);
        if(authId == null){
            authId = userId;
        }
        MediatorLiveData<List<Float>> totaleLiveData = new MediatorLiveData<>();
        String finalAuthId = authId;
        totaleLiveData.addSource(categorieLiveData, categorie -> {
            if (categorie != null && !categorie.isEmpty()) {
                List<Float> totaleList = new ArrayList<>();
                AtomicInteger counter = new AtomicInteger(0);

                for (String categoria : categorie) {
                    LiveData<Float> totaleSpeseCategoriaLiveData = getTotaleSpeseCategoria(finalAuthId, tipoSpesa, categoria);

                    totaleLiveData.addSource(totaleSpeseCategoriaLiveData, totaleSpese -> {
                        totaleList.add(totaleSpese);

                        if (counter.incrementAndGet() == categorie.size()) {
                            totaleLiveData.setValue(totaleList);
                        }

                        totaleLiveData.removeSource(totaleSpeseCategoriaLiveData);
                    });
                }
            } else {
                totaleLiveData.setValue(Collections.emptyList());
            }
        });

        return totaleLiveData;
    }

    public LiveData<Float> getTotaleSpeseCategoria(
            String authId, String tipoSpesa, String categoria) {
        if(authId == null){
            authId = userId;
        }
        MutableLiveData<Float> totaleSpeseLiveData = new MutableLiveData<>();

        db.collection("spese")
                .whereEqualTo("authId", authId)
                .whereEqualTo("tipoSpesa", tipoSpesa)
                .whereEqualTo("categoria", categoria)
                .addSnapshotListener((querySnapshot, error) -> {
                    if (error != null) {
                        return;
                    }

                    float totaleSpese = 0f;

                    for (QueryDocumentSnapshot document : querySnapshot) {
                        // Assicurati che il campo "importo" esista e sia un numero
                        if (document.contains("importo") && document.get("importo") instanceof Number) {
                            float importo = ((Number) document.get("importo")).floatValue();
                            totaleSpese += importo;
                        }
                    }

                    totaleSpeseLiveData.setValue(totaleSpese);
                });

        return totaleSpeseLiveData;
    }

    private static Timestamp getTimestampFromDate(Date date) {
        return date != null ? new Timestamp(date) : null;
    }

    public void loadCategoriesFromFirebase(Consumer<Set<String>> categoriesCallback) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String authId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        db.collection("spese")
                .whereEqualTo("authId", authId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    Set<String> uniqueCategories = new HashSet<>();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        String categoryName = document.getString("categoria");
                        if (categoryName != null) {
                            uniqueCategories.add(categoryName);
                        }
                    }

                    categoriesCallback.accept(uniqueCategories);
                })
                .addOnFailureListener(e -> {
                });
    }

    public List<Spesa> exportToCSV(String authId){
        List<Spesa> expenses = new ArrayList<>();
        db.collection("spese")
                .whereEqualTo("authId", authId)
                .orderBy("data")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {


                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Spesa spesa = document.toObject(Spesa.class);
                        expenses.add(spesa);
                    }});
        return expenses;
    }

}


