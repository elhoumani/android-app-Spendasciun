package it.unimib.spendaciun.ui.welcome;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.commons.validator.routines.EmailValidator;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.util.TextViewUtils;

public class LoginFragment extends Fragment {

    private TextInputLayout emailComponente;
    private TextInputLayout passwordComponente;
    private CheckBox saveCredentialsCheckBox;
    private ProgressBar progressBar;
    private WelcomeViewModel welcomeViewModel;

    public LoginFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WelcomeViewModelFactory factory = new WelcomeViewModelFactory(requireActivity().getApplicationContext());
        welcomeViewModel = new ViewModelProvider(this, factory).get(WelcomeViewModel.class);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setupViews(view);
        setupButtons(view);
        observeViewModel();

        if (welcomeViewModel.getRememberMe()) {
            String[] credentials = welcomeViewModel.getCredentials();
            if (credentials[0] != null && credentials[1] != null) {
                performLogin(credentials[0], credentials[1]);
            }
        }
    }

    private void setupViews(View view) {
        emailComponente = view.findViewById(R.id.emailEditText);
        passwordComponente = view.findViewById(R.id.passwordEditText);
        saveCredentialsCheckBox = view.findViewById(R.id.checkBox);
        progressBar = view.findViewById(R.id.loginProgressBar);
        TextView textView = view.findViewById(R.id.mainTitle);
        TextViewUtils.setAutoSizeTextTypeUniform(textView);
    }

    private void setupButtons(View view) {
        Button loginButton = view.findViewById(R.id.buttonLogin);
        Button registresBtn = view.findViewById(R.id.registresButton);
        Button recuperoPswBtn = view.findViewById(R.id.forgotPswd);

        loginButton.setOnClickListener(v -> handleLoginClick());
        registresBtn.setOnClickListener(v -> navigateToRegistrationFragment());
        recuperoPswBtn.setOnClickListener(v -> navigateToRecuperoPswFragment());
        saveCredentialsCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> handleSaveCredentialsCheck());
    }

    private void handleLoginClick() {
        String email = emailComponente.getEditText().getText().toString();
        String password = passwordComponente.getEditText().getText().toString();
        if (isEmailValid(email) && isPswdValid(password)) {
            performLogin(email, password);
        } else {
            Snackbar.make(requireView(), R.string.loginError, Snackbar.LENGTH_SHORT).show();
        }
    }

    private void handleSaveCredentialsCheck() {
        welcomeViewModel.setRememberMe(saveCredentialsCheckBox.isChecked());
    }

    private void navigateToRegistrationFragment() {
        Navigation.findNavController(requireView()).navigate(R.id.action_loginFragment_to_registrationFragment);
    }

    private void navigateToRecuperoPswFragment() {
        Navigation.findNavController(requireView()).navigate(R.id.action_loginFragment_to_recuperoPswFragment);
    }

    private void performLogin(String email, String password) {
        progressBar.setVisibility(View.VISIBLE);
        welcomeViewModel.loginUser(email, password);
    }

    private void observeViewModel() {
        welcomeViewModel.getLoginSuccess().observe(getViewLifecycleOwner(), success -> {
            progressBar.setVisibility(View.GONE);
            if (success) {
                Snackbar.make(requireView(), R.string.loginOk, Snackbar.LENGTH_SHORT).show();
                Navigation.findNavController(requireView()).navigate(R.id.action_loginFragment_to_mainActivity);
            } else {
                Snackbar.make(requireView(), R.string.loginError, Snackbar.LENGTH_SHORT).show();
            }
        });

        welcomeViewModel.getOperationFailed().observe(getViewLifecycleOwner(), exception -> {
            progressBar.setVisibility(View.GONE);
            Snackbar.make(requireView(), R.string.loginError, Snackbar.LENGTH_SHORT).show();
        });
    }

    private boolean isEmailValid(String email) {
        return EmailValidator.getInstance().isValid(email);
    }

    private boolean isPswdValid(String password) {
        return password != null && !password.isEmpty();
    }
}
