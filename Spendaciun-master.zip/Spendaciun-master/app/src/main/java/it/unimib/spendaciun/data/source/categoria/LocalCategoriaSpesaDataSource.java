package it.unimib.spendaciun.data.source.categoria;

import androidx.lifecycle.LiveData;

import com.google.firebase.auth.FirebaseAuth;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import it.unimib.spendaciun.data.database.categoria.CategoriaSpesaDao;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;

public class LocalCategoriaSpesaDataSource {

    private final CategoriaSpesaDao categoriaSpesaDao;
    private final Executor executor;

    public LocalCategoriaSpesaDataSource(CategoriaSpesaDao categoriaSpesaDao) {
        this.categoriaSpesaDao = categoriaSpesaDao;
        this.executor = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<CategoriaSpesa>> getAllCategorie(String userId) {
        return categoriaSpesaDao.getCategorieUtente(userId);
    }

    public void insertCategoriaSpesa(CategoriaSpesa categoriaSpesa) {
        executor.execute(() -> {
            if (categoriaSpesa.getId() == null) {
                categoriaSpesa.setId(UUID.randomUUID().toString());
            }
            categoriaSpesaDao.insert(categoriaSpesa);
        });
    }

    public void updateCategoriaSpesa(CategoriaSpesa categoriaSpesa) {
        executor.execute(() -> categoriaSpesaDao.update(categoriaSpesa));
    }

    public void deleteCategoriaSpesa(CategoriaSpesa categoriaSpesa) {
        executor.execute(() -> categoriaSpesaDao.delete(categoriaSpesa));
    }

    public void deleteByUserId(String userId) {
        executor.execute(() -> categoriaSpesaDao.deleteByUserId(userId));
    }

    public void deleteByItemId(String itemId) {
        executor.execute(() -> categoriaSpesaDao.deleteByItemId(itemId));
    }

    public void deleteAllCategorie() {
        executor.execute(categoriaSpesaDao::deleteAll);
    }

    public LiveData<Integer> getCategorieCount() {
        // Utilizza un altro thread o un approccio asincrono se necessario.
        // LiveData<Integer> può essere gestito tramite Room direttamente se supportato, o indirettamente tramite un approccio custom.
        // Per semplicità, qui lasciamo una segnaposto per indicare che questo metodo dovrebbe essere implementato in base alle specifiche esigenze.
        throw new UnsupportedOperationException("getCategorieCount needs to be implemented.");
    }

    public String getUserId() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        return  userId;
    }
}
