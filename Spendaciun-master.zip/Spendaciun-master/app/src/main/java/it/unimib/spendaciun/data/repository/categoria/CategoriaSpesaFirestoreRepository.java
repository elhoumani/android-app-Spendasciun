package it.unimib.spendaciun.data.repository.categoria;

import androidx.lifecycle.LiveData;

import java.util.List;

import it.unimib.spendaciun.data.source.categoria.RemoteCategoriaSpesaDataSource;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;

public class CategoriaSpesaFirestoreRepository {

    private RemoteCategoriaSpesaDataSource remoteDataSource;

    public CategoriaSpesaFirestoreRepository() {
        remoteDataSource = new RemoteCategoriaSpesaDataSource();
    }

    public void addCategoria(CategoriaSpesa categoria) {
        remoteDataSource.addCategoria(categoria);
    }

    public LiveData<List<CategoriaSpesa>> getCategorie() {
        return remoteDataSource.getCategorie();
    }

    public void deleteCategoria(String categoriaId) {
        remoteDataSource.deleteCategoria(categoriaId);
    }

    public void deleteAllCategorie() {
        remoteDataSource.deleteAllCategorie().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
            } else {
            }
        });
    }

    public void addDefaultCategories() { remoteDataSource.addDefaultCategories();    }
}
