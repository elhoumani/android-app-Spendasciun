package it.unimib.spendaciun.ui.main.fragment.impostazioni;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModel;

import android.app.Activity;
import android.app.Application;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.net.Uri;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;

import android.content.Intent;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;
import android.Manifest;

import it.unimib.spendaciun.data.repository.categoria.CategoriaSpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.user.UserRepository;
import it.unimib.spendaciun.ui.welcome.WelcomeActivity;
import it.unimib.spendaciun.util.firestore.FirestoreExporter;
import it.unimib.spendaciun.util.firestore.FirestoreImport;

public class SettingsViewModel extends AndroidViewModel {

    private static final int REQUEST_WRITE_STORAGE = 112;
    private static final int PICK_CSV_FILE = 113;
    private SpesaFirestoreRepository helper;
    private CategoriaSpesaFirestoreRepository helperCategoria;
    private UserRepository helperUser;

    private String currentUserId;

    public String getCurrentAuthId() {
        return helper.getCurrentAuthId();
    }


    public SettingsViewModel(Application application) {
        super(application);
        helper = new SpesaFirestoreRepository();
        helperCategoria = new CategoriaSpesaFirestoreRepository();
        helperUser = new UserRepository();
        currentUserId = getCurrentAuthId();
    }


    public void deleteAccount(String authId) {
        helper.deleteAllSpese(authId);
        helperCategoria.deleteAllCategorie();
        helperUser.deleteUser(authId);
        helperUser.deleteCurrentUserAccount();
    }

    public void importTransactions(Context context, Uri csvUri, String collection, String userId) {
        FirestoreImport firestoreImport = new FirestoreImport(context);
        firestoreImport.importCSV(csvUri, collection, userId);
    }

    public void exportTransactions(Context context, String currentUserId) {
        FirestoreExporter.exportToCSV(context, currentUserId);
    }

    public void redirect(Context context) {
        Intent intent = new Intent(context, WelcomeActivity.class);
        context.startActivity(intent);
        if (context instanceof Activity) {
            ((Activity) context).finish();
        }
    }

    public boolean checkWritePermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    public void requestWritePermission(Activity activity) {
        activity.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_STORAGE);
    }

    public void handleActivityResult(int requestCode, int resultCode, Intent data, Context context) {
        // Implementazione per gestire i risultati delle attività
        if (requestCode == PICK_CSV_FILE && resultCode == Activity.RESULT_OK) {
            Uri csvUri = data.getData();
            importTransactions(context, csvUri, "yourCollection", currentUserId);
        }
    }
}
