    package it.unimib.spendaciun.util.dialog;

    import android.app.DatePickerDialog;
    import android.app.Dialog;
    import android.graphics.Color;
    import android.os.Bundle;
    import android.widget.Button;
    import android.widget.DatePicker;
    import android.widget.EditText;

    import androidx.fragment.app.DialogFragment;

    import java.text.SimpleDateFormat;
    import java.util.Calendar;
    import java.util.Date;
    import java.util.GregorianCalendar;
    import java.util.Locale;

    import it.unimib.spendaciun.R;

    public class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        private OnDateSelectedListener dateSelectedListener;

        public DatePickerFragment() {
        }

        public DatePickerFragment(OnDateSelectedListener listener) {
            this.dateSelectedListener = listener;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), R.style.DatePickerDialogTheme, this, year, month, day);

            datePickerDialog.setOnShowListener(dialogInterface -> {
                Button positiveButton = datePickerDialog.getButton(Dialog.BUTTON_POSITIVE);
                Button negativeButton = datePickerDialog.getButton(Dialog.BUTTON_NEGATIVE);

                positiveButton.setTextColor(Color.BLACK);
                negativeButton.setTextColor(Color.BLACK);
            });

            return datePickerDialog;
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            Calendar selectedCalendar = new GregorianCalendar(year, month, day);
            Date selectedDate = selectedCalendar.getTime();

            if (dateSelectedListener != null) {
                dateSelectedListener.onDateSelected(selectedDate);
            }
        }
        public interface OnDateSelectedListener {
            void onDateSelected(Date selectedDate);
        }


    }

