package it.unimib.spendaciun.util.firestore;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.math.BigDecimal;
import java.math.RoundingMode;
import it.unimib.spendaciun.model.spesa.Spesa;
import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;

public class FirestoreImport {

    private Context context;
    private ImporterViewModel importerViewModel;

    public FirestoreImport(Context context) {
        this.context = context;
        this.importerViewModel = new ImporterViewModel();
    }

    public void importCSV(Uri csvUri, String collectionName, String authId) {
        try {
            InputStream is = context.getContentResolver().openInputStream(csvUri);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            String line;
            boolean isFirstLine = true;
            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }

                String[] parts = line.split(",");

                if (parts.length < 6) {
                    continue;
                }

                Spesa spesa = createSpesaFromCSV(parts, authId);
                Log.d("FirestoreImport", "Importing expense: " + spesa);
                importerViewModel.addSpesa(spesa);
            }

            reader.close();
            is.close();

            Toast.makeText(context, "L'import è andato a buon fine!", Toast.LENGTH_SHORT).show();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    private Spesa createSpesaFromCSV(String[] parts, String authId) throws ParseException {
        String id = parts[0].trim().replace("\"", "");
        String nome = parts[1].trim().replace("\"", "");
        String categoria = parts[4].trim().replace("\"", "");
        String tipoSpesa = parts[5].trim().replace("\"", "");

        String importoString = parts[2].trim().replace("\"", "").replace(",", ".");
        BigDecimal importo = new BigDecimal(importoString).setScale(2, RoundingMode.HALF_UP);

        String dataString = parts[3].trim().replace("\"", "");

        SimpleDateFormat originalDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date data = null;

        try {
            data = originalDateFormat.parse(dataString);
        } catch (ParseException e) {
            SimpleDateFormat fallbackDateFormat = new SimpleDateFormat("dd/MM/yyyy");
            data = fallbackDateFormat.parse(dataString);
        }

        return new Spesa(
                id.isEmpty() ? null : id,
                authId,
                nome,
                importo.doubleValue(),
                data,
                categoria,
                tipoSpesa
        );
    }

}
