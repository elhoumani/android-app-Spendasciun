package it.unimib.spendaciun.util.dialog;

import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.data.repository.spesa.SpesaRepository;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;
import it.unimib.spendaciun.model.spesa.Spesa;
import it.unimib.spendaciun.ui.main.fragment.scanner.ScannerViewModel;

public class AddExpenseDialogFragment extends DialogFragment {

    private EditText editNomeSpesaSc;
    private Button buttonCategoriaSc;
    private EditText editImportoSc, editDataSc;
    private Button buttonConferma;
    private ScannerViewModel mViewModel;
    private String userId;
    private CategoriaSpesa selectedCategoria;
    private String amount;
    private String date;

    public AddExpenseDialogFragment(String amount, String date) {
        this.amount = amount;
        this.date = date;

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_scanner_addexp, null);
        builder.setView(view);
        Application application = getActivity().getApplication();
        mViewModel = new ScannerViewModel(application);
        userId = mViewModel.ottieniId();
        editImportoSc = view.findViewById(R.id.editImportoSc);
        editDataSc = view.findViewById(R.id.editDataSc);
        editNomeSpesaSc = view.findViewById(R.id.editNomeSpesaSc);
        buttonCategoriaSc = view.findViewById(R.id.buttonCategoriaSc);
        buttonConferma = view.findViewById(R.id.buttonConfermaSc);

        if (amount != null && !amount.isEmpty()) {
            editImportoSc.setText(amount);
        }
        if (date != null && !date.isEmpty()) {
            editDataSc.setText(date);
        }

        buttonCategoriaSc.setOnClickListener(v -> showCategorySelectDialog());
        buttonConferma.setOnClickListener(v -> {
            String nomeSpesa = editNomeSpesaSc.getText().toString();
            String importo = editImportoSc.getText().toString();


            boolean isImportoValid = false;
            try {
                Double.parseDouble(importo);
                isImportoValid = true;
            } catch (NumberFormatException e) {

                isImportoValid = false;
            }

            if (isImportoValid ) {
                aggiungiSpesa(nomeSpesa, importo, selectedCategoria);
                Snackbar.make(view, R.string.scattare_caricare, Snackbar.LENGTH_LONG).show();
                dismiss();
            } else {
                Snackbar.make(view, R.string.riempireCampi, Snackbar.LENGTH_LONG).show();
            }
        });

        return builder.create();
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
        }
    }

    private void showCategorySelectDialog() {

        CategorySelectDialogFragment dialog = new CategorySelectDialogFragment(userId, "Uscita");
        dialog.setOnCategoriaSelectedListener(new CategorySelectDialogFragment.OnCategoriaSelectedListener() {
            @Override
            public void onCategoriaSelected(CategoriaSpesa categoria) {
                selectedCategoria = categoria;
                String nome = selectedCategoria.getNomeCategoria();

                buttonCategoriaSc.setText(nome);
            }
        });
        dialog.show(getParentFragmentManager(), "categorySelect");
    }

    public void aggiungiSpesa(String nomeSpesa, String importo, CategoriaSpesa selectedCategoria){
        if (!TextUtils.isEmpty(nomeSpesa)  && !TextUtils.isEmpty(importo) && selectedCategoria != null) {
            String dataSelezionataString = editDataSc.getText().toString();
            Date dataSelezionata = null;

            try {
                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                dataSelezionata = formato.parse(dataSelezionataString);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            Spesa nuovaSpesa = new Spesa(userId, nomeSpesa, Double.parseDouble(importo), dataSelezionata, selectedCategoria.getNomeCategoria(), "Uscita");
            mViewModel.addSpesa(nuovaSpesa);
            editImportoSc.setText("");
            editDataSc.setText("");

        }
    }

}
