package it.unimib.spendaciun.ui.main.fragment.aggiungiSpesa;

import static com.google.android.material.internal.ContextUtils.getActivity;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.spesa.SpesaRepository;
import it.unimib.spendaciun.data.repository.user.UserRepository;
import it.unimib.spendaciun.model.spesa.Spesa;

public class AggiungiSpesaViewModel extends AndroidViewModel {
    private SpesaRepository mSpesaRepo;
    private SpesaFirestoreRepository fSpesaRepo;
    private UserRepository mUserRepo;
    private final MutableLiveData<String> mText;

    public AggiungiSpesaViewModel(Application application) {
        super(application);
        mText = new MutableLiveData<>();
        mSpesaRepo = new SpesaRepository(application);
        mUserRepo = new UserRepository();
        fSpesaRepo = new SpesaFirestoreRepository();
    }

    public LiveData<String> getText() {
        return mText;
    }

    public void insert(Spesa spesa){
        mSpesaRepo.insert(spesa);
    }

    public void addSpesa(Spesa spesa){
        fSpesaRepo.addSpesa(spesa);
    }

    public String getCurrentAuth() {
        return mUserRepo.getCurretUser().getUid();
    }
}