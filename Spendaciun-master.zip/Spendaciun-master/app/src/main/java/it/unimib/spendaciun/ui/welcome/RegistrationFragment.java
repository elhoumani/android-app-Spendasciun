package it.unimib.spendaciun.ui.welcome;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import it.unimib.spendaciun.R;

public class RegistrationFragment extends Fragment {
    private TextInputLayout textInputLayoutEmail;
    private TextInputLayout textInputLayoutPassword;
    private TextInputLayout textInputLayoutConfirmPassword;
    private TextInputLayout textInputLayoutName;
    private Button registrationButton;
    private ProgressBar progressBar;

    private WelcomeViewModel welcomeViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_registration, container, false);

        initializeUI(rootView);
        WelcomeViewModelFactory factory = new WelcomeViewModelFactory(requireActivity().getApplicationContext());
        welcomeViewModel = new ViewModelProvider(this, factory).get(WelcomeViewModel.class);
        setupObservers();

        registrationButton.setOnClickListener(view -> attemptRegistration());

        return rootView;
    }

    private void initializeUI(View rootView) {
        textInputLayoutEmail = rootView.findViewById(R.id.textInputLayout2);
        textInputLayoutPassword = rootView.findViewById(R.id.textInputLayout3);
        textInputLayoutConfirmPassword = rootView.findViewById(R.id.textInputLayout4);
        textInputLayoutName = rootView.findViewById(R.id.textInputLayout);
        registrationButton = rootView.findViewById(R.id.button2);
        progressBar = rootView.findViewById(R.id.registrazioneProgressBar);
    }

    private void setupObservers() {
        welcomeViewModel.getIsLoading().observe(getViewLifecycleOwner(), isLoading -> progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE));

        welcomeViewModel.getRegistrationSuccess().observe(getViewLifecycleOwner(), isSuccess -> {
            if (isSuccess) {
                Navigation.findNavController(getView()).navigate(R.id.loginFragment);
            }
        });

        welcomeViewModel.getOperationFailed().observe(getViewLifecycleOwner(), exception -> {
            if (exception != null) {
                Snackbar.make(requireView(), exception.getMessage(), Snackbar.LENGTH_LONG).show();
            }
        });
    }

    private void attemptRegistration() {
        String email = textInputLayoutEmail.getEditText().getText().toString().trim();
        String password = textInputLayoutPassword.getEditText().getText().toString().trim();
        String confirmPassword = textInputLayoutConfirmPassword.getEditText().getText().toString().trim();
        String name = textInputLayoutName.getEditText().getText().toString().trim();

        if (validateInput(email, password, confirmPassword, name)) {
            welcomeViewModel.registerUser(name, email, password);
        }
    }

    private boolean validateInput(String email, String password, String confirmPassword, String name) {
        textInputLayoutEmail.setError(null);
        textInputLayoutPassword.setError(null);
        textInputLayoutConfirmPassword.setError(null);
        textInputLayoutName.setError(null);

        if (name.isEmpty()) {
            textInputLayoutName.setError(getString(R.string.error_field_required));
            return false;
        }
        if (email.isEmpty()) {
            textInputLayoutEmail.setError(getString(R.string.error_field_required));
            return false;
        } else if (!email.contains("@")) {
            textInputLayoutEmail.setError(getString(R.string.error_invalid_email));
            return false;
        }

        if (password.isEmpty()) {
            textInputLayoutPassword.setError(getString(R.string.error_field_required));
            return false;
        } else if (password.length() < 6) {
            textInputLayoutPassword.setError(getString(R.string.error_invalid_password));
            return false;
        }

        if (!password.equals(confirmPassword)) {
            textInputLayoutConfirmPassword.setError(getString(R.string.error_password_match));
            return false;
        }

        return true;
    }

}
