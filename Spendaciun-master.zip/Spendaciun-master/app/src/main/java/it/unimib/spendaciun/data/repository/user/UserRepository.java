package it.unimib.spendaciun.data.repository.user;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import it.unimib.spendaciun.data.source.spesa.RemoteSpesaDataSource;
import it.unimib.spendaciun.data.source.user.RemoteUserDataSource;

public class UserRepository {

    private RemoteUserDataSource mUserData;

    public UserRepository() {
        mUserData = new RemoteUserDataSource();
    }

    public void deleteUser(String authId) {
        mUserData.deleteUser(authId);
    }

    public void deleteCurrentUserAccount() {
        mUserData.deleteCurrentUserAccount();
    }

    public FirebaseUser getCurretUser() {
        return mUserData.getCurretUser();
    }

    public void loadUserInformation(String userId, Consumer<Map<String, Object>> onSuccess) {
        mUserData.loadUserInformation(userId, onSuccess);
    }

    public void loginUser(String email, String password, AuthCallback authCallback) {
        mUserData.loginUser(email, password, authCallback);
    }

    public void registerUser(String name, String email, String password, Consumer<Boolean> onSuccess, Consumer<Exception> onFailure) {
        mUserData.registerUser(name, email, password, onSuccess, onFailure);
    }

    public void resetUserPassword(String email, Consumer<Boolean> onSuccess, Consumer<Exception> onFailure) {
        mUserData.resetUserPassword(email, onSuccess, onFailure);
    }

    public void logoutUser() {
        mUserData.logoutUser();
    }

    public void updateUserName(String uid, String newName) {
        mUserData.updateUserName(uid, newName);
    }
}
