package it.unimib.spendaciun.model.categoria;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import it.unimib.spendaciun.data.repository.categoria.CategoriaSpesaRepository;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;

// Assumendo che CategoriaSpesaRepository non richieda l'Application per essere istanziato.
// Se necessario, utilizzare ViewModelProvider.Factory per passare le dipendenze.
public class CategoriaSpesaViewModel extends AndroidViewModel {

    private CategoriaSpesaRepository mRepository;
    private LiveData<List<CategoriaSpesa>> mAllCategorie;

    public CategoriaSpesaViewModel(Application application) {
        super(application);
        mRepository = new CategoriaSpesaRepository(application);
        mAllCategorie = mRepository.getAllCategorie();
    }

    public void insert(CategoriaSpesa categoriaSpesa) {
        mRepository.insert(categoriaSpesa);
    }

    public void insertList(List<CategoriaSpesa> categorie) {
        for (CategoriaSpesa categoria : categorie) {
            mRepository.insert(categoria);
        }
    }

    public void deleteByUser(String userId) {
        mRepository.deleteByUserId(userId);
    }

    public void delete(String itemId) {
        mRepository.deleteByItemId(itemId);
    }

    public void deleteAll() {
        mRepository.deleteAll();
    }
}
