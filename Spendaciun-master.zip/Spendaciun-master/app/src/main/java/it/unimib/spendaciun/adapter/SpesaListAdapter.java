package it.unimib.spendaciun.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;
import it.unimib.spendaciun.model.spesa.Spesa;
import it.unimib.spendaciun.model.spesa.SpesaViewModel;
import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.ui.main.fragment.listaSpese.HomeViewModel;

public class SpesaListAdapter extends RecyclerView.Adapter<SpesaListAdapter.SpesaViewHolder> {

    private final LayoutInflater mInflater;
    private List<Spesa> mSpese;
    private List<Spesa> tutteLeSpese;
    private HomeViewModel homeViewModel;

    public SpesaListAdapter(Context context, HomeViewModel homeViewModel1) {
        mInflater = LayoutInflater.from(context);
        homeViewModel = homeViewModel1;
    }

    class SpesaViewHolder extends RecyclerView.ViewHolder {
        private final TextView nomeTextView;
        private final TextView importoTextView;
        private final TextView dataTextView;

        private final TextView categoriaTextView;
        private final ImageView iconaCategoria;

        public SpesaViewHolder(View itemView) {
            super(itemView);
            nomeTextView = itemView.findViewById(R.id.SpesaNome);
            importoTextView = itemView.findViewById(R.id.SpesaImporto);

            categoriaTextView = itemView.findViewById(R.id.SpesaCategoria);
            dataTextView = itemView.findViewById(R.id.SpesaData);
            iconaCategoria = itemView.findViewById(R.id.iconaCategoria);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    int position = getAdapterPosition();
                    Spesa spesaDaEliminare = mSpese.get(position);
                    String id = spesaDaEliminare.getId();

                    Log.d("SpesaListAdapter", "id" + id);

                    // Mostra un dialogo di conferma
                    new AlertDialog.Builder(v.getContext())
                            .setTitle("Conferma eliminazione")
                            .setMessage("Sei sicuro di voler eliminare questa spesa?")
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    homeViewModel.delete(id);
                                }
                            })
                            .setNegativeButton(android.R.string.no, null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();

                    return true;
                }
            });
        }
    }

    @Override
    public SpesaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_item, parent, false);
        return new SpesaViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(SpesaViewHolder holder, int position) {
        if (mSpese != null) {
            Spesa current = mSpese.get(position);

            holder.nomeTextView.setText(current.getNome());

            // Controllo per il tipo di spesa e formattazione dell'importo
            String importoFormatted = (current.getTipoSpesa().equals("Uscita") ? "-" : "") + String.valueOf(current.getImporto());
            holder.importoTextView.setText(importoFormatted);

            // Formattazione e impostazione della data
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
            String formattedDate = dateFormat.format(current.getData()).toUpperCase(Locale.getDefault());
            holder.dataTextView.setText(formattedDate);

            // Impostazione della categoria
            holder.categoriaTextView.setText(current.getCategoria());

            CategoriaSpesa category = new CategoriaSpesa();
            String iconName = category.getIconName(current.getTipoSpesa());
            int resourceId = holder.itemView.getContext().getResources().getIdentifier(iconName, "drawable", holder.itemView.getContext().getPackageName());
            holder.iconaCategoria.setImageResource(resourceId);

        } else {
            // Covers the case of data not being ready yet
            holder.nomeTextView.setText("No Spesa");
        }
    }
    public void setExpenses(List<Spesa> spese){ // funzionalità che riguarda direttamente la visualizzazione dei dati è appropriato che risieda nell'Adapter
        if (tutteLeSpese == null) {
            tutteLeSpese = new ArrayList<>(spese);
        } else {
            tutteLeSpese.clear();
            tutteLeSpese.addAll(spese);
        }
        mSpese = spese;
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        if (mSpese != null)
            return mSpese.size();
        else return 0;
    }
    
}