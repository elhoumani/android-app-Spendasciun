package it.unimib.spendaciun.ui.main.fragment.listaSpese;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.adapter.SpesaListAdapter;
import it.unimib.spendaciun.model.spesa.Spesa;
import it.unimib.spendaciun.model.spesa.SpesaViewModel;
import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import com.google.firebase.auth.FirebaseAuth;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel ;
    private RecyclerView mRecyclerView;
    private SpesaListAdapter mAdapter;
    private Button entrateBtn;
    private Button usciteBtn;
    private Button totaleBtn;
    private TextView totaleTextView;
    private TextView sumTotaleTextView;
    private TextView profileTextView;
    private TextView operazioneTextView;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);
        setupViews(view);

        setupLiveDataObservers();
        setupButtons();

        refreshDataFromFirebase();

        return view;
    }




    private void refreshDataFromFirebase() {
        homeViewModel.deleteAll();

        LiveData<List<Spesa>> speseFirebase = homeViewModel.getSpese();
        speseFirebase.observe(getViewLifecycleOwner(), newSpese -> {
            if (newSpese != null) {
                homeViewModel.insertList(speseFirebase);


            }
        });

        homeViewModel.getAllSpese().observe(getViewLifecycleOwner(), speseObserver);


        homeViewModel.getFilteredSpese().observe(getViewLifecycleOwner(), new Observer<List<Spesa>>() {

            @Override
            public void onChanged(List<Spesa> speseFiltrate) {
                mAdapter.setExpenses(speseFiltrate);
            }

        });
    }

    private void setupViews(View view) {
        mRecyclerView = view.findViewById(R.id.recyclerview);
        mAdapter = new SpesaListAdapter(requireContext(), homeViewModel);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        entrateBtn = view.findViewById(R.id.buttonEntrate);
        usciteBtn = view.findViewById(R.id.buttonUscite);
        totaleBtn = view.findViewById(R.id.buttonTotale);


        totaleTextView = view.findViewById(R.id.textViewTotalTypeAmount);
        sumTotaleTextView = view.findViewById(R.id.textViewTotalTypeAmount);


        profileTextView = view.findViewById(R.id.ProfileTextView);


        operazioneTextView = view.findViewById(R.id.operazioniText);
        operazioneTextView.setText("Operazioni Totali");


        homeViewModel.getUserNameLiveData().observe(getViewLifecycleOwner(), userName -> {
            if (userName != null) profileTextView.setText(userName);
        });
    }

    private void setupLiveDataObservers() {
        homeViewModel.getAllSpese().observe(getViewLifecycleOwner(), speseObserver);
        homeViewModel.getFilteredSpese().observe(getViewLifecycleOwner(), this::updateSpeseList);
    }

    private void setupButtons() {
        entrateBtn.setOnClickListener(v -> handleEntrateClick());
        usciteBtn.setOnClickListener(v -> handleUsciteClick());
        totaleBtn.setOnClickListener(v -> handleTotaleClick());
    }

    private void handleEntrateClick() {
        homeViewModel.filterSpese("Entrata");
        double entryAmmount = homeViewModel.getAllAmountByType("Entrata");
        String entryAmmountFormatted = String.format(Locale.getDefault(), "%.2f €", entryAmmount);
        String entryAmmountText = "Entrate: " + entryAmmountFormatted;
        totaleTextView.setText(entryAmmountText);
        operazioneTextView.setText("Operazioni in Entrata");
    }

    private void handleUsciteClick() {
        homeViewModel.filterSpese("Uscita");
        double expensesAmmount = homeViewModel.getAllAmountByType("Uscita");
        String expensesAmmountFormatted = String.format(Locale.getDefault(), "-%.2f €", expensesAmmount);
        String expensesAmmountText = "Uscite: " + expensesAmmountFormatted;
        totaleTextView.setText(expensesAmmountText);
        operazioneTextView.setText("Operazioni in Uscita");
    }

    private void handleTotaleClick() {
        homeViewModel.filterAllSpese();
        double totalAmount = homeViewModel.getTotalAmount();
        String formattedTotal = String.format(Locale.getDefault(), "%.2f €", totalAmount);
        totaleTextView.setText("Saldo Totale: " + formattedTotal);
        operazioneTextView.setText("Operazioni Totali");
    }

    private void updateSpeseList(List<Spesa> spese) {
        if (spese != null) {
            mAdapter.setExpenses(spese);
            updateTotal();
        }
    }

    private void updateTotal() {
        double total = homeViewModel.getTotalAmount();
        String formattedTotal = String.format(Locale.getDefault(), "%.2f €", total);
        sumTotaleTextView.setText("Saldo Totale: " + formattedTotal);
    }

    private final Observer<List<Spesa>> speseObserver = new Observer<List<Spesa>>() {
        @Override
        public void onChanged(@Nullable final List<Spesa> spese) {
            if (spese != null) {
                Collections.sort(spese, new Comparator<Spesa>() {
                    @Override
                    public int compare(Spesa o1, Spesa o2) {
                        return o2.getData().compareTo(o1.getData());
                    }
                });

                mAdapter.setExpenses(spese);

                double total = homeViewModel.getTotalAmount();
                String formattedTotal = String.format(Locale.getDefault(), "%.2f €", total);
                String totalText = "Saldo Totale: " + formattedTotal;
                sumTotaleTextView.setText(totalText);


            }
        }
    };
}
