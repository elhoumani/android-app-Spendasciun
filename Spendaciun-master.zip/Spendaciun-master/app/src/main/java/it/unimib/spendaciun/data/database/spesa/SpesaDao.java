package it.unimib.spendaciun.data.database.spesa;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import it.unimib.spendaciun.model.spesa.Spesa;

@Dao
public interface SpesaDao {

    @Query("SELECT * FROM spesa_table WHERE authId = :authId")
    LiveData<List<Spesa>> getSpeseUtente(String authId);

    @Query("SELECT * FROM spesa_table")
    LiveData<List<Spesa>> getAll();

    @Insert
    void insert(Spesa spesa);

    @Query("SELECT * FROM spesa_table WHERE id IN (:spesaIds)")
    List<Spesa> loadAllByIds(int[] spesaIds);

    @Query("SELECT * FROM spesa_table WHERE nome LIKE :nome LIMIT 1")
    Spesa findByName(String nome);

    @Insert
    void insertAll(Spesa... spese);

    @Update
    void update(Spesa spesa);

    @Delete
    void delete(Spesa spesa);

    // Metodo per eliminare tutte le spese di un utente
    @Query("DELETE FROM spesa_table WHERE authId = :userId")
    void deleteByUserId(String userId);
    @Query("DELETE FROM spesa_table WHERE id = :itemId")
    void deleteByItemId(String itemId);

    @Query("SELECT COUNT(*) FROM spesa_table")
    int getSpeseCount();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertFirebase(Spesa spesa);

    @Query("DELETE FROM spesa_table")
    void deleteAll();

}
