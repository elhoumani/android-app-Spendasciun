package it.unimib.spendaciun.ui.shared;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class SharedViewModel extends ViewModel {
    private final MutableLiveData<String> recognizedAmount = new MutableLiveData<>();
    private final MutableLiveData<String> recognizedDate = new MutableLiveData<>();

    public void setRecognizedAmount(String amount) {
        recognizedAmount.setValue(amount);
    }

    public void setRecognizedDate(String date) {
        recognizedDate.setValue(date);
    }

    public LiveData<String> getRecognizedAmount() {
        return recognizedAmount;
    }

    public LiveData<String> getRecognizedDate() {
        return recognizedDate;
    }

}
