package it.unimib.spendaciun.ui.main.fragment.listaSpese;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.List;

import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.spesa.SpesaRepository;
import it.unimib.spendaciun.data.repository.user.UserRepository;
import it.unimib.spendaciun.model.spesa.Spesa;

public class HomeViewModel extends AndroidViewModel {

    private SpesaFirestoreRepository mFirebase;
    private SpesaRepository mRepository;
    private UserRepository mUserRepo;
    private LiveData<List<Spesa>> mAllSpese;
    private MutableLiveData<List<Spesa>> filteredSpese = new MutableLiveData<>();
    private MutableLiveData<Double> totalLiveData;
    private MutableLiveData<String> userNameLiveData = new MutableLiveData<>();
    public LiveData<List<Spesa>> getSpeseUtente(String authId) {
        return getSpeseUtente(authId);
    }
    public LiveData<List<Spesa>> getAllSpese() {
        return mRepository.getAllSpese();
    }
    public LiveData<String> getUserNameLiveData() { return userNameLiveData; }

    public HomeViewModel(Application application) {
        super(application);
        mRepository = new SpesaRepository(application);
        mFirebase = new SpesaFirestoreRepository();
        mUserRepo = new UserRepository();
        mAllSpese = mRepository.getAllSpese();
        totalLiveData = new MutableLiveData<>();

        loadUserName();
    }

    public void deleteAll(){
        mRepository.deleteAll();

    }

    public void insertList(LiveData<List<Spesa>> speseFirebase) {
        speseFirebase.observeForever(new Observer<List<Spesa>>() {
            @Override
            public void onChanged(List<Spesa> spese) {
                if (spese != null && !spese.isEmpty()) {
                    for (Spesa spesa : spese) {
                        mRepository.insert(spesa);
                    }
                }
            }
        });
    }

    private void loadUserName() {
        String userId = mUserRepo.getCurretUser().getUid();;

        mUserRepo.loadUserInformation(userId, userData -> {
            if (userData != null) {
                String name = (String) userData.get("name");
                userNameLiveData.postValue(name);
            }
        });
    }


    public LiveData<List<Spesa>> getSpese() {
        return mFirebase.getSpese();
    }


    public LiveData<List<Spesa>> getFilteredSpese() {
        return filteredSpese;
    }

    public void filterSpese(String type) {
        if (mAllSpese.getValue() == null) {
            filteredSpese.setValue(new ArrayList<>());
            return;
        }

        List<Spesa> filteredList = new ArrayList<>();
        for (Spesa spesa : mAllSpese.getValue()) {
            if (spesa.getTipoSpesa().equals(type)) {
                filteredList.add(spesa);
            }
        }
        filteredSpese.setValue(filteredList);
    }

    public void filterAllSpese() {
        if (mAllSpese.getValue() == null) {
            filteredSpese.setValue(new ArrayList<>());
            return;
        }

        List<Spesa> allList = new ArrayList<>(mAllSpese.getValue());
        filteredSpese.setValue(allList);
    }

    public double getTotalAmount() {

        double totAmmount, totalEntry, totalExpsenses;

        totAmmount = 0.0;
        totalEntry = getAllAmountByType("Entrata");
        totalExpsenses = getAllAmountByType("Uscita");

        totAmmount = totalEntry - totalExpsenses;

        return totAmmount;
    }

    public double getAllAmountByType(String type){
        double totalAmount = 0.0;
        if (mAllSpese.getValue() != null) {
            for (Spesa spesa : mAllSpese.getValue()) {
                if (spesa.getTipoSpesa().equals(type)) {
                    totalAmount += spesa.getImporto();
                }
            }
        }
        return totalAmount;
    }

    public boolean isEmpty() {
        return mRepository.isEmpty();
    }

    public void delete(String id) {
        mFirebase.deleteSpesa(id);
        mRepository.deleteByItemId(id);
    }
}