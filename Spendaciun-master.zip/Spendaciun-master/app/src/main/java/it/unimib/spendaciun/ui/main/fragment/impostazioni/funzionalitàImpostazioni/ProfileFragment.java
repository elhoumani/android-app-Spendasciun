package it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.data.repository.user.UserRepository;
import it.unimib.spendaciun.ui.welcome.WelcomeViewModel;
import it.unimib.spendaciun.ui.welcome.WelcomeViewModelFactory;

public class ProfileFragment extends Fragment {
    private EditText textInputName;
    private EditText textInputEmail;
    private Button editButton, saveButton;
    private ProfileViewModel mViewModel;
    private FirebaseUser currentUser;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        mViewModel = new ProfileViewModel();
        textInputName = view.findViewById(R.id.textInputName);
        editButton = view.findViewById(R.id.editButton);
        saveButton = view.findViewById(R.id.saveButton);
        textInputEmail = view.findViewById(R.id.textInputEmail);

        currentUser = mViewModel.getCurretUser();

        if (currentUser != null) {
            loadUserProfile(currentUser.getUid());
        }

        editButton.setOnClickListener(v -> toggleEdit(true));
        saveButton.setOnClickListener(v -> {
            saveUserProfile(currentUser);
            toggleEdit(false);
        });

        return view;
    }

    private void loadUserProfile(String userId) {
        mViewModel.loadUserInformation(userId, userData -> {
            if (userData != null) {
                textInputName.setText((String) userData.get("name"));
                textInputEmail.setText((String) userData.get("email"));
                textInputEmail.setEnabled(false);
            }
        });
    }

    private void saveUserProfile(FirebaseUser currentUser) {
        if (currentUser != null) {
            String newName = textInputName.getText().toString();

            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                    .setDisplayName(newName)
                    .build();

            currentUser.updateProfile(profileUpdates)
                    .addOnCompleteListener(profileUpdateTask -> {
                        if (profileUpdateTask.isSuccessful()) {
                            mViewModel.updateUserName(currentUser.getUid(), newName);
                        }
                    });
        }
    }

    private void toggleEdit(boolean isEditing) {
        textInputName.setEnabled(isEditing);
        saveButton.setVisibility(isEditing ? View.VISIBLE : View.GONE);
        editButton.setVisibility(isEditing ? View.GONE : View.VISIBLE);
    }
}
