package it.unimib.spendaciun.util.firestore;

import java.util.List;

import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.model.spesa.Spesa;

public class ExporterViewModel {
    private SpesaFirestoreRepository mRepo;

    public ExporterViewModel(){
        mRepo = new SpesaFirestoreRepository();
    }

    public List<Spesa> exportToCSV(String authId) {
        return mRepo.exportToCSV(authId);
    }
}
