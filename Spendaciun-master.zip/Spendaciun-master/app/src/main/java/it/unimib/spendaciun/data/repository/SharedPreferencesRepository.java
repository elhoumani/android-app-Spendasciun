package it.unimib.spendaciun.data.repository;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

public class SharedPreferencesRepository{
    private static final String TAG = "SharedPreferencesRepo";
    private SharedPreferences sharedPreferences;

    public SharedPreferencesRepository(Context context) throws GeneralSecurityException, IOException {
        MasterKey mainKey = new MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build();

        this.sharedPreferences = EncryptedSharedPreferences.create(
                context,
                "encrypted_prefs",
                mainKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        );
        Log.d(TAG, "EncryptedSharedPreferences initialized.");
    }

    public String getEmail() {
        return sharedPreferences.getString("USER_EMAIL", null);
    }

    public String getPassword() {
        return sharedPreferences.getString("USER_PASSWORD", null);
    }

    public void setNightModeEnabled(boolean isEnabled) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("night_mode_enabled", isEnabled);
        editor.apply();
    }

    public boolean isNightModeEnabled() {
        return sharedPreferences.getBoolean("night_mode_enabled", false);
    }

    public void saveCredentials(String email, String password) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("USER_EMAIL", email);
        editor.putString("USER_PASSWORD", password);
        editor.apply();
    }

    public void clearCredentials() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("USER_EMAIL");
        editor.remove("USER_PASSWORD");
        editor.apply();
    }


    public void setRememberMe(boolean rememberMe) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("REMEMBER_ME", rememberMe);
        editor.apply();
    }

    public boolean getRememberMe() {
        return sharedPreferences.getBoolean("REMEMBER_ME", false);
    }

}
