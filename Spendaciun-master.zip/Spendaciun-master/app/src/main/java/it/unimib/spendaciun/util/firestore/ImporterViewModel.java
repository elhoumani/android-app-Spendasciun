package it.unimib.spendaciun.util.firestore;

import java.util.List;

import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.model.spesa.Spesa;

public class ImporterViewModel {
    private SpesaFirestoreRepository mRepo;

    public ImporterViewModel(){
        mRepo = new SpesaFirestoreRepository();
    }

    public void addSpesa(Spesa spesa) {
        mRepo.addSpesa(spesa);
    }
}
