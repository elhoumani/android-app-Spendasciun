package it.unimib.spendaciun.ui.main.fragment.scanner;

import android.app.Application;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.widget.EditText;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.spesa.SpesaRepository;
import it.unimib.spendaciun.data.repository.user.UserRepository;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;
import it.unimib.spendaciun.model.spesa.Spesa;
import it.unimib.spendaciun.ui.shared.SharedViewModel;


public class ScannerViewModel extends AndroidViewModel {

    private MutableLiveData<Uri> imageUri = new MutableLiveData<>();
    private MutableLiveData<String> textScanned = new MutableLiveData<>();

     private SharedViewModel sharedViewModel;
     private SpesaFirestoreRepository mSpesaRepo;

    public ScannerViewModel(@NonNull Application application) {
        super(application);
        mSpesaRepo = new SpesaFirestoreRepository();
    }

    public MutableLiveData<Uri> getImageUri() {
        return imageUri;
    }

    public void launchCamera(ActivityResultLauncher<Intent> launcher) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Image");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera");
        Uri imageUri = getApplication().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        this.imageUri.postValue(imageUri);
        launcher.launch(cameraIntent);
    }

    public void launchGallery(ActivityResultLauncher<Intent> launcher) {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        launcher.launch(galleryIntent);
    }

    public void setSharedViewModel(SharedViewModel sharedViewModel) {
        this.sharedViewModel = sharedViewModel;
    }

    public void addSpesa(Spesa nuovaSpesa) {
        mSpesaRepo.addSpesa(nuovaSpesa);
    }
    public String ottieniId(){
        return mSpesaRepo.getCurrentAuthId();
    }
}
