package it.unimib.spendaciun.model.crypto;

import java.util.ArrayList;

public class Crypto {
    private String name;
    private double price;
    private ArrayList<CryptoData> history;

    public Crypto(String name, double price, ArrayList<CryptoData> history) {
        this.name = name;
        this.price = price;
        this.history = history;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public ArrayList<CryptoData> getHistory() {
        return history;
    }
}