package it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni;

import android.app.Application;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class CryptoViewModelFactory implements ViewModelProvider.Factory {
    private Application application;

    public CryptoViewModelFactory(Application application) {
        this.application = application;
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        if (modelClass.isAssignableFrom(CryptoViewModel.class)) {
            return (T) new CryptoViewModel(application);
        }
        throw new IllegalArgumentException("Unknown ViewModel class");
    }
}
