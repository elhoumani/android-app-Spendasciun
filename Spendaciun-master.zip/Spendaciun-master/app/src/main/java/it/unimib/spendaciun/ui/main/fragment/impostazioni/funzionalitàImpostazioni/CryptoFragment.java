package it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.adapter.CryptoAdapter;
import it.unimib.spendaciun.model.crypto.Crypto;

public class CryptoFragment extends Fragment {

    private RecyclerView recyclerView;
    private CryptoAdapter adapter;
    private ArrayList<Crypto> cryptoList;
    private CryptoViewModel viewModel;
    private ProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_crypto, container, false);

        recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        cryptoList = new ArrayList<>();
        adapter = new CryptoAdapter(cryptoList, requireContext());
        recyclerView.setAdapter(adapter);
        progressBar = view.findViewById(R.id.progress_bar);

        return view;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        CryptoViewModelFactory factory = new CryptoViewModelFactory(requireActivity().getApplication());
        viewModel = new ViewModelProvider(this, factory).get(CryptoViewModel.class);
        initViewModel();
    }

    private void initViewModel() {
        viewModel.getCryptoData().observe(getViewLifecycleOwner(), data -> {
            cryptoList.clear();
            cryptoList.addAll(data);
            adapter.notifyDataSetChanged();
            progressBar.setVisibility(ProgressBar.GONE);
        });

        viewModel.getIsLoading().observe(getViewLifecycleOwner(), isLoading -> {
            if (isLoading) {
                progressBar.setVisibility(ProgressBar.VISIBLE);
            } else {
                progressBar.setVisibility(ProgressBar.GONE);
            }
        });

        viewModel.loadCryptoDataIfNeeded();
    }

    @Override
    public void onResume() {
        super.onResume();
        viewModel.onActivityResumed();
        viewModel.getLoadCryptoDataTrigger().observe(getViewLifecycleOwner(), load -> {
            if (load) {
                viewModel.loadCryptoData();
            }
        });
    }
}
