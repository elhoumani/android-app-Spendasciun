package it.unimib.spendaciun.model.categoria;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


@Entity(tableName = "categoria_spesa_table")
public class CategoriaSpesa {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "id")
    private String id;

    @ColumnInfo(name = "authId")
    private String authId;

    @ColumnInfo(name = "nomeCategoria")
    private String nomeCategoria;

    @ColumnInfo(name = "tipo")
    private String tipo;

    public CategoriaSpesa() {}

    @Ignore
    public CategoriaSpesa(String nomeCategoria, String tipo) {
        this.authId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        this.nomeCategoria = nomeCategoria;
        this.tipo = tipo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAuthId() {
        return authId;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public String getNomeCategoria() {
        return nomeCategoria;
    }

    public void setNomeCategoria(String nomeCategoria) {
        this.nomeCategoria = nomeCategoria;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getIconName(String tipo) {
        System.out.println("Tipo di categoria: " + tipo);
        if (tipo != null) {
            if (tipo.equalsIgnoreCase("Entrata")) {
                return "icon_entrate";
            } else if (tipo.equalsIgnoreCase("Uscita")) {
                return "icon_uscite";
            } else {
                return "icon_category";
            }
        }
    return "icon_category";
    }
}

