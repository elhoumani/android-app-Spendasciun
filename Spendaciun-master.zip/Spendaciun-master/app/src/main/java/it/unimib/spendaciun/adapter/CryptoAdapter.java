package it.unimib.spendaciun.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.listener.ChartTouchListener;
import com.github.mikephil.charting.listener.OnChartGestureListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.model.crypto.Crypto;
import it.unimib.spendaciun.model.crypto.CryptoData;

public class CryptoAdapter extends RecyclerView.Adapter<CryptoAdapter.CryptoViewHolder> {
    private ArrayList<Crypto> cryptoList;
    private Context context;

    public CryptoAdapter(ArrayList<Crypto> cryptoList, Context context) {
        this.cryptoList = cryptoList;
        this.context = context;
    }

    @NonNull
    @Override
    public CryptoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.crypto_item, parent, false);
        return new CryptoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CryptoViewHolder holder, int position) {
        Crypto crypto = cryptoList.get(position);
        holder.nameTextView.setText(crypto.getName());
        holder.priceTextView.setText(String.valueOf(crypto.getPrice()));

        List<Entry> entries = new ArrayList<>();
        for (CryptoData data : crypto.getHistory()) {
            // Converti il timestamp in anni.
            float year = convertTimestampToYear(data.getTimestamp());
            entries.add(new Entry(year, data.getValue()));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Price History");
        dataSet.setColor(Color.BLUE);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setDrawCircles(false);

        LineData lineData = new LineData(dataSet);
        holder.chart.setData(lineData);

        configureChartGestureListener(holder.chart);

        holder.chart.invalidate(); // refreshes the chart
    }

    @Override
    public int getItemCount() {
        return cryptoList.size();
    }

    static class CryptoViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView priceTextView;
        LineChart chart;

        public CryptoViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.name_text_view);
            priceTextView = itemView.findViewById(R.id.price_text_view);
            chart = itemView.findViewById(R.id.chart);
        }
    }


    private void configureChartGestureListener(final LineChart chart) {
        chart.setOnChartGestureListener(new OnChartGestureListener() {
            @Override
            public void onChartGestureStart(MotionEvent me, ChartTouchListener.ChartGesture lastPerformedGesture) {}

            @Override
            public void onChartGestureEnd(MotionEvent me, ChartTouchListener.ChartGesture lastPerformedGesture) {
            }

            @Override
            public void onChartLongPressed(MotionEvent me) {}

            @Override
            public void onChartDoubleTapped(MotionEvent me) {}

            @Override
            public void onChartSingleTapped(MotionEvent me) {}

            @Override
            public void onChartFling(MotionEvent me1, MotionEvent me2, float velocityX, float velocityY) {}

            @Override
            public void onChartScale(MotionEvent me, float scaleX, float scaleY) {}

            @Override
            public void onChartTranslate(MotionEvent me, float dX, float dY) {}
        });
    }

    private float convertTimestampToYear(float timestamp) {
        return timestamp / 1000 / 31536000; // Converti il timestamp in secondi, poi in anni.
    }
}
