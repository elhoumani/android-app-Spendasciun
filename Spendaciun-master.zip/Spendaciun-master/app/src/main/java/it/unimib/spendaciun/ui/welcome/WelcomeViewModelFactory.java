package it.unimib.spendaciun.ui.welcome;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;


public class WelcomeViewModelFactory implements ViewModelProvider.Factory {
    private final Context context;

    public WelcomeViewModelFactory(Context context) {
        this.context = context.getApplicationContext();
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        if (modelClass.isAssignableFrom(WelcomeViewModel.class)) {
            return (T) new WelcomeViewModel(context);
        }
        throw new IllegalArgumentException("Unknown ViewModel class");
    }
}
