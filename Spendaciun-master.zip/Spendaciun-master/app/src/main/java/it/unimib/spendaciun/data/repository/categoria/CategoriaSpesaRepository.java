package it.unimib.spendaciun.data.repository.categoria;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

import com.google.firebase.auth.FirebaseAuth;

import it.unimib.spendaciun.data.database.categoria.CategoriaSpesaDao;
import it.unimib.spendaciun.data.database.categoria.CategoriaSpesaRoomDatabase;
import it.unimib.spendaciun.data.source.categoria.LocalCategoriaSpesaDataSource;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;

public class CategoriaSpesaRepository {

    private LocalCategoriaSpesaDataSource localDataSource;
    private LiveData<List<CategoriaSpesa>> mAllCategorie;
    private String userId;

    public CategoriaSpesaRepository(Application application) {
        CategoriaSpesaRoomDatabase db = CategoriaSpesaRoomDatabase.getDatabase(application);
        CategoriaSpesaDao categoriaSpesaDao = db.categoriaSpesaDao();
        localDataSource = new LocalCategoriaSpesaDataSource(categoriaSpesaDao);
        userId = getUserId();
        mAllCategorie = localDataSource.getAllCategorie(userId);
    }

    public String getUserId(){
        return localDataSource.getUserId();
    }

    public LiveData<List<CategoriaSpesa>> getAllCategorie() {
        return localDataSource.getAllCategorie(userId);
    }

    public void insert(CategoriaSpesa categoriaSpesa) {
        localDataSource.insertCategoriaSpesa(categoriaSpesa);
    }

    public void delete(CategoriaSpesa categoriaSpesa) {
        localDataSource.deleteCategoriaSpesa(categoriaSpesa);
    }

    public void deleteAll() {
        localDataSource.deleteAllCategorie();
    }

    public void deleteByItemId(String itemId) {
        localDataSource.deleteByItemId(itemId);
    }

    public void deleteByUserId(String userId) {
        localDataSource.deleteByUserId(userId);
    }
}
