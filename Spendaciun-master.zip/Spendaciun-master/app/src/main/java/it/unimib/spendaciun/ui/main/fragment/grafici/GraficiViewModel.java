package it.unimib.spendaciun.ui.main.fragment.grafici;

import android.util.Log;

import androidx.core.util.Consumer;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.Date;
import java.util.List;
import java.util.Set;

import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;

public class GraficiViewModel extends ViewModel {
    private final MutableLiveData<String> mText;
    private SpesaFirestoreRepository mFirebase;
    private final MediatorLiveData<List<Float>> totaleUsciteLiveData;
    private final MediatorLiveData<List<Float>> totaleEntrateLiveData;

    public GraficiViewModel() {
        mText = new MutableLiveData<>();
        mFirebase = new SpesaFirestoreRepository();
        totaleUsciteLiveData = new MediatorLiveData<>();
        totaleEntrateLiveData = new MediatorLiveData<>();
    }

    public LiveData<String> getText() {
        return mText;
    }

    public LiveData<List<String>> getCategorieUtente(String userId, String tipoSpesa, List<String> selectedCategories, Date startDate, Date endDate) {
        Log.d("FILTRO CATEGORIE", "Selceted Categories: " + selectedCategories);
        return mFirebase.getCategorieUtente(userId, tipoSpesa, selectedCategories, startDate, endDate);
    }

    public LiveData<List<Float>> getTotaleCategorie(String authId, String tipoSpesa, List<String> selectedCategories, Date startDate, Date endDate) {
        return mFirebase.getTotaleCategorie(authId, tipoSpesa, selectedCategories, startDate, endDate);
    }

    public void loadCategoriesFromFirebase(Consumer<Set<String>> categoriesCallback) {
        mFirebase.loadCategoriesFromFirebase(categoriesCallback);
    }

    public String getAuth() {
        return mFirebase.getCurrentAuthId();
    }
}
