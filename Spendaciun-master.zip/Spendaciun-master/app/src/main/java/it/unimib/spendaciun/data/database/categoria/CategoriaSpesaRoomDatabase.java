package it.unimib.spendaciun.data.database.categoria;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import it.unimib.spendaciun.model.categoria.CategoriaSpesa;
import it.unimib.spendaciun.util.Converters;

@Database(entities = {CategoriaSpesa.class}, version = 7, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class CategoriaSpesaRoomDatabase extends RoomDatabase {

    public abstract CategoriaSpesaDao categoriaSpesaDao();

    private static volatile CategoriaSpesaRoomDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static CategoriaSpesaRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (CategoriaSpesaRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    CategoriaSpesaRoomDatabase.class, "categoria_spesa_database")
                            .fallbackToDestructiveMigration()
                            .addMigrations(MIGRATION_1_2)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            // Perform migration logic here
            // For example, you can recreate the table
            database.execSQL("CREATE TABLE IF NOT EXISTS `categoria_spesa_table` (" +
                    "`id` INTEGER PRIMARY KEY NOT NULL, " +
                    "`authId` INTEGER NOT NULL," +
                    "`nomeCategoria` TEXT NOT NULL, " +
                    "`tipo` TEXT NOT NULL" +
                    ")");
        }
    };
}
