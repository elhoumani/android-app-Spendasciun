package it.unimib.spendaciun.data.repository.spesa;

import androidx.core.util.Consumer;
import androidx.lifecycle.LiveData;

import java.util.Date;
import java.util.List;
import java.util.Set;

import it.unimib.spendaciun.data.source.spesa.RemoteSpesaDataSource;
import it.unimib.spendaciun.model.spesa.Spesa;

public class SpesaFirestoreRepository {

    private RemoteSpesaDataSource remoteDataSource;

    public SpesaFirestoreRepository() {
        remoteDataSource = new RemoteSpesaDataSource();
    }

    public void addSpesa(Spesa spesa) {
        remoteDataSource.addSpesa(spesa);
    }

    public LiveData<List<Spesa>> getSpese() {
        return remoteDataSource.getSpese();
    }

    public void deleteSpesa(String spesaId) {
        remoteDataSource.deleteSpesa(spesaId);
    }

    public String getCurrentAuthId(){
        return remoteDataSource.getCurrentAuthId();
    }

    public void deleteAllSpese(String userId) {
        remoteDataSource.deleteAll(userId).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
            } else {
            }
        });
    }

    public LiveData<List<String>> getCategorieUtente(String userId, String tipoSpesa, List<String> selectedCategories, Date startDate, Date endDate) {
    return remoteDataSource.getCategorieUtente(userId, tipoSpesa, selectedCategories, startDate, endDate);
    }

    public LiveData<List<Float>> getTotaleCategorie(String authId, String tipoSpesa, List<String> selectedCategories, Date startDate, Date endDate) {
    return remoteDataSource.getTotaleCategorie(authId, tipoSpesa, selectedCategories, startDate, endDate);
    }


    public void loadCategoriesFromFirebase(Consumer<Set<String>> categoriesCallback) {
        remoteDataSource.loadCategoriesFromFirebase(categoriesCallback);
    }

    public List<Spesa> exportToCSV(String authId) {
        return remoteDataSource.exportToCSV(authId);
    }
}
