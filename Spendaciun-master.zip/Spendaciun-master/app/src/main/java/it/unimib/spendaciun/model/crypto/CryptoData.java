package it.unimib.spendaciun.model.crypto;


public class CryptoData {
    float timestamp;
    float value;

    public CryptoData(float timestamp, float value) {
        this.timestamp = timestamp;
        this.value = value;
    }

    public float getTimestamp() {
        return timestamp;
    }

    public float getValue() {
        return value;
    }
}
