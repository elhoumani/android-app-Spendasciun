package it.unimib.spendaciun.util.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.stream.Collectors;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;
import it.unimib.spendaciun.adapter.CategoriaSpesaListAdapter;
import it.unimib.spendaciun.data.repository.categoria.CategoriaSpesaFirestoreRepository;
import it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni.CategoriaManagerViewModel;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class CategorySelectDialogFragment extends DialogFragment {
    private String userId;
    private String tipoCategoria;
    private CategoriaManagerViewModel managerViewModel;
    private CategoriaSpesaListAdapter adapter;
    private OnCategoriaSelectedListener mListener;

    public CategorySelectDialogFragment(String userId, String tipoCategoria) {
        this.userId = userId;
        this.tipoCategoria = tipoCategoria;
        managerViewModel = new CategoriaManagerViewModel();
    }

    public interface OnCategoriaSelectedListener {
        void onCategoriaSelected(CategoriaSpesa categoria);
    }

    public void setOnCategoriaSelectedListener(OnCategoriaSelectedListener listener) {
        mListener = listener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(getActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_categories, null);

        RecyclerView recyclerView = view.findViewById(R.id.recycler_view_categories);
        adapter = new CategoriaSpesaListAdapter(getContext());
        adapter.setOnItemClickListener(new CategoriaSpesaListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(CategoriaSpesa categoria) {
            }

            @Override
            public void onDeleteClick(CategoriaSpesa categoria) {
            }

            @Override
            public void onSingleSelect(CategoriaSpesa categoria) {
                if (mListener != null) {
                    mListener.onCategoriaSelected(categoria);
                }
                dismiss();
            }
        });

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        builder.setView(view);

        loadCategorieFromFirebase();
        return builder.create();
    }

    private void loadCategorieFromFirebase() {
        managerViewModel.getCategorie().observe(this, new Observer<List<CategoriaSpesa>>() {
            @Override
            public void onChanged(List<CategoriaSpesa> categoriaSpesas) {
                List<CategoriaSpesa> filteredCategorie = categoriaSpesas.stream()
                        .filter(categoria -> categoria.getTipo().equals(tipoCategoria))
                        .collect(Collectors.toList());
                adapter.setCategorie(filteredCategorie);
            }
        });
    }


}
