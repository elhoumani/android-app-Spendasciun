package it.unimib.spendaciun.ui.main.fragment.impostazioni;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Switch;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.preference.PreferenceManager;

import com.google.android.material.progressindicator.LinearProgressIndicator;


import android.Manifest;
import it.unimib.spendaciun.R;
import it.unimib.spendaciun.ui.welcome.WelcomeViewModel;
import it.unimib.spendaciun.ui.welcome.WelcomeViewModelFactory;

public class SettingsFragment extends Fragment {

    private static final int PICK_CSV_FILE = 113;
    private SettingsViewModel settingsViewModel;
    private WelcomeViewModel welcomeViewModel;
    private Button profileButton;
    private Button deleteAccountButton;
    private Button importTransactionsButton;
    private Button exportTransactionsButton;
    private Button categoryManagementButton;
    private String currentUserId;
    private Switch nightModeSwitch;
    private Button cryptoButton;
    private Button logoutButton;
    private LinearProgressIndicator progressIndicator;

    private ActivityResultLauncher<Intent> activityResultLauncher;
    private ActivityResultLauncher<String[]> requestPermissionLauncher;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        settingsViewModel = new ViewModelProvider(this).get(SettingsViewModel.class);
        WelcomeViewModelFactory factory = new WelcomeViewModelFactory(requireActivity().getApplicationContext());
        welcomeViewModel = new ViewModelProvider(this, factory).get(WelcomeViewModel.class);

        profileButton = view.findViewById(R.id.profileButton);
        deleteAccountButton = view.findViewById(R.id.delete_account);
        importTransactionsButton = view.findViewById(R.id.import_transactions_button);
        exportTransactionsButton = view.findViewById(R.id.export_transactions_button);
        categoryManagementButton = view.findViewById(R.id.gestioneCategorieButton);
        nightModeSwitch = view.findViewById(R.id.night_mode_switch);
        cryptoButton = view.findViewById(R.id.crypto_button);
        logoutButton = view.findViewById(R.id.logout_button);
        progressIndicator = view.findViewById(R.id.progress_indicator);

        currentUserId = settingsViewModel.getCurrentAuthId();

        setupListeners();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        boolean isNightModeEnabled = preferences.getBoolean("night_mode_enabled", false);
        nightModeSwitch.setChecked(isNightModeEnabled);


        activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK) {
                Intent data = result.getData();
                settingsViewModel.handleActivityResult(PICK_CSV_FILE, result.getResultCode(), data, getContext());
            }
        });
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
                    boolean allPermissionsGranted = permissions.values().stream().allMatch(granted -> granted);
                    if (allPermissionsGranted) {
                    } else {
                    }
                });

        return view;
    }

    private void setupListeners() {
        profileButton.setOnClickListener(v -> navigateToProfileFragment());
        deleteAccountButton.setOnClickListener(v -> showDeleteAccountConfirmationDialog());

        importTransactionsButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            activityResultLauncher.launch(intent);
        });

        exportTransactionsButton.setOnClickListener(v -> {
            if (settingsViewModel.checkWritePermission(getContext())) {
                settingsViewModel.exportTransactions(getContext(), currentUserId);
            } else {
                settingsViewModel.requestWritePermission(getActivity());
                requestPermissionLauncher.launch(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE});
            }
        });

        categoryManagementButton.setOnClickListener(v -> navigateToCategoryManagementFragment());

        nightModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            boolean isCurrentlyNightMode = (getResources().getConfiguration().uiMode &
                    Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

            if ((isChecked && !isCurrentlyNightMode) || (!isChecked && isCurrentlyNightMode)) {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("night_mode_enabled", isChecked);
                editor.apply();

                AppCompatDelegate.setDefaultNightMode(isChecked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);

                getActivity().recreate();
            }
        });

        cryptoButton.setOnClickListener(v -> navigateToCryptoFragment());

        logoutButton.setOnClickListener(v -> {
            logout();
        });
    }

    private void logout(){
        welcomeViewModel.logoutUser();
        settingsViewModel.redirect(getContext());
    }

    private void showDeleteAccountConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Conferma Eliminazione")
                .setMessage("Sei sicuro di voler eliminare il tuo account? Questa azione è irreversibile.")
                .setPositiveButton("Elimina", (dialog, which) -> {
                    progressIndicator.setVisibility(View.VISIBLE);
                    settingsViewModel.deleteAccount(currentUserId);
                    logout();
                })
                .setNegativeButton("Annulla", (dialog, which) -> progressIndicator.setVisibility(View.GONE))
                .show();
    }

    private void navigateToProfileFragment() {
        Navigation.findNavController(requireView()).navigate(R.id.action_settingsFragment_to_profileFragment);
    }

    private void navigateToCategoryManagementFragment() {
        Navigation.findNavController(requireView()).navigate(R.id.action_settingsFragment_to_gestioneCategorieFragment);
    }

    private void navigateToCryptoFragment() {
        Navigation.findNavController(requireView()).navigate(R.id.action_settingsFragment_to_cryptoFragment);
    }

}
