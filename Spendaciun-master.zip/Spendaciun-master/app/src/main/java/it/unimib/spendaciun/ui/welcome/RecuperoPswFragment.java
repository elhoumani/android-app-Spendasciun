package it.unimib.spendaciun.ui.welcome;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Patterns;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

import it.unimib.spendaciun.R;

public class RecuperoPswFragment extends Fragment {

    private EditText editTextEmail;
    private Button buttonRecoverPassword;
    private WelcomeViewModel welcomeViewModel;

    public RecuperoPswFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WelcomeViewModelFactory factory = new WelcomeViewModelFactory(requireActivity().getApplicationContext());
        welcomeViewModel = new ViewModelProvider(this, factory).get(WelcomeViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_recupero_password, container, false);

        editTextEmail = view.findViewById(R.id.editTextEmail);
        buttonRecoverPassword = view.findViewById(R.id.buttonRecoverPassword);


        buttonRecoverPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recuperaPassword();
            }
        });



        return view;
    }

    public void recuperaPassword(){
        String email = String.valueOf(editTextEmail);
        welcomeViewModel.resetUserPassword(email);
    }


}
