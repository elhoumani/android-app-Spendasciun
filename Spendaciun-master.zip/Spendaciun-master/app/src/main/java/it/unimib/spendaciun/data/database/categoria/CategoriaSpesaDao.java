package it.unimib.spendaciun.data.database.categoria;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import it.unimib.spendaciun.model.categoria.CategoriaSpesa;

@Dao
public interface CategoriaSpesaDao {

    @Query("SELECT * FROM categoria_spesa_table WHERE authId = :authId")
    LiveData<List<CategoriaSpesa>> getCategorieUtente(String authId);

    @Query("SELECT * FROM categoria_spesa_table")
    LiveData<List<CategoriaSpesa>> getAll();

    @Insert
    void insert(CategoriaSpesa categoriaSpesa);

    @Query("SELECT * FROM categoria_spesa_table WHERE id IN (:categoriaIds)")
    List<CategoriaSpesa> loadAllByIds(int[] categoriaIds);

    @Query("SELECT * FROM categoria_spesa_table WHERE nomeCategoria LIKE :nome LIMIT 1")
    CategoriaSpesa findByName(String nome);

    @Insert
    void insertAll(CategoriaSpesa... categorie);

    @Update
    void update(CategoriaSpesa categoriaSpesa);

    @Delete
    void delete(CategoriaSpesa categoriaSpesa);

    // Metodo per eliminare tutte le categorie di un utente
    @Query("DELETE FROM categoria_spesa_table WHERE authId = :userId")
    void deleteByUserId(String userId);

    @Query("SELECT COUNT(*) FROM categoria_spesa_table")
    int getCategorieCount();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertFirebase(CategoriaSpesa categoriaSpesa);

    @Query("DELETE FROM categoria_spesa_table")
    void deleteAll();

    @Query("DELETE FROM categoria_spesa_table WHERE id = :itemId")
    void deleteByItemId(String itemId);
}

