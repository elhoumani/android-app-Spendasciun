package it.unimib.spendaciun.data.database.spesa;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import it.unimib.spendaciun.model.spesa.Spesa;
import it.unimib.spendaciun.util.Converters;

@Database(entities = {Spesa.class}, version = 5,exportSchema = false)
@TypeConverters({Converters.class})
public abstract class SpesaRoomDatabase extends RoomDatabase {

    public abstract SpesaDao spesaDao();

    private static volatile SpesaRoomDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static SpesaRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (SpesaRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    SpesaRoomDatabase.class, "spesa_database")
                            .fallbackToDestructiveMigration()
                            .addMigrations(MIGRATION_1_2)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            // Perform migration logic here
            // For example, you can recreate the table
            database.execSQL("CREATE TABLE IF NOT EXISTS `spesa_table` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "`authId` TEXT NOT NULL," + // Fix: Use backticks for field names
                    "`nome` TEXT, " +
                    "`data` INTEGER, " +
                    "`importo` REAL NOT NULL, " +
                    "`categoria` TEXT" +
                    ")");
        }
    };
}
