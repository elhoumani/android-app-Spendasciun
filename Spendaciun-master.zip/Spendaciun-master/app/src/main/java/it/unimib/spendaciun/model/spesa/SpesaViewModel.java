package it.unimib.spendaciun.model.spesa;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import java.util.ArrayList;
import java.util.List;

import it.unimib.spendaciun.data.repository.spesa.SpesaRepository;

public class SpesaViewModel extends AndroidViewModel {

    private SpesaRepository mRepository;
    private LiveData<List<Spesa>> mAllSpese;

    public SpesaViewModel(Application application) {
        super(application);
        mRepository = new SpesaRepository(application);
        mAllSpese = mRepository.getAllSpese();
    }
    private MutableLiveData<List<Spesa>> filteredSpese = new MutableLiveData<>();
    public void insert(Spesa spesa) {
        mRepository.insert(spesa);
    }

    public void deleteByUser(String userId) {
        mRepository.deleteByUserId(userId);
    }

    public void delete(String itemId) {
        mRepository.deleteByItemId(itemId);
    }

    public boolean isEmpty() {
        return mRepository.isEmpty();
    }


    public void deleteAll() {
        Log.d("SpesaViewModel", "deleteAll called");
        mRepository.deleteAll();
    }
}
