package it.unimib.spendaciun.data.repository.user;


public interface AuthCallback {
    void onSuccess();
    void onFailure(Exception e);
}

