package it.unimib.spendaciun.data.source.crypto;

import android.os.Build;
import android.content.Context;
import androidx.annotation.RequiresApi;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.concurrent.Executors;

import it.unimib.spendaciun.data.database.categoria.CategoriaSpesaDao;
import it.unimib.spendaciun.model.crypto.Crypto;
import it.unimib.spendaciun.model.crypto.CryptoData;

public class CoinGeckoDataSource {
    private static final String BASE_URL = "https://api.coingecko.com/api/v3/";

    public CoinGeckoDataSource() {
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public ArrayList<Crypto> getCryptoData(Context context) {
        ArrayList<Crypto> cryptoList = new ArrayList<>();

        try {
            InputStream inputStream = context.getAssets().open("cryptoapi.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String response = readFromBuffer(reader);
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                Crypto crypto = parseCrypto(jsonObject);
                if (crypto != null) {
                    cryptoList.add(crypto);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cryptoList;
    }

    private static String readFromBuffer(BufferedReader reader) throws Exception {
        StringBuilder builder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }
        reader.close();
        return builder.toString();
    }

    private static Crypto parseCrypto(JSONObject jsonObject) throws Exception {
        String name = jsonObject.getString("name");
        double price = jsonObject.getDouble("current_price");
        String id = jsonObject.getString("id");
        long endDate = System.currentTimeMillis() / 1000L;
        long startDate = LocalDateTime.of(1970, Month.NOVEMBER, 1, 0, 0).toEpochSecond(ZoneOffset.UTC);
        String historyUrl = BASE_URL + "coins/" + id + "/market_chart/range?vs_currency=usd&from=" + startDate + "&to=" + endDate;

        HttpURLConnection connectionHistory = null;
        try {
            URL urlHistory = new URL(historyUrl);
            connectionHistory = (HttpURLConnection) urlHistory.openConnection();
            connectionHistory.setRequestMethod("GET");

            String responseHistory = readFromBuffer(new BufferedReader(new InputStreamReader(connectionHistory.getInputStream())));
            ArrayList<CryptoData> history = parseHistory(new JSONObject(responseHistory));

            return new Crypto(name, price, history);
        } finally {
            if (connectionHistory != null) {
                connectionHistory.disconnect();
            }
        }
    }

    private static ArrayList<CryptoData> parseHistory(JSONObject jsonObjectHistory) throws Exception {
        JSONArray pricesArray = jsonObjectHistory.getJSONArray("prices");
        ArrayList<CryptoData> history = new ArrayList<>();
        for (int j = 0; j < pricesArray.length(); j++) {
            JSONArray pricePoint = pricesArray.getJSONArray(j);
            long timestamp = pricePoint.getLong(0) / 1000;
            float value = (float) pricePoint.getDouble(1);
            history.add(new CryptoData(timestamp, value));
        }
        return history;
    }
}
