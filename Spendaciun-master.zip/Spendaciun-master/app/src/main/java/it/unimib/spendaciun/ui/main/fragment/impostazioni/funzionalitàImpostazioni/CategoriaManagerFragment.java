package it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;
import java.util.stream.Collectors;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.adapter.CategoriaSpesaListAdapter;
import it.unimib.spendaciun.data.repository.categoria.CategoriaSpesaFirestoreRepository;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;
import it.unimib.spendaciun.model.categoria.CategoriaSpesaViewModel;
import it.unimib.spendaciun.model.spesa.SpesaViewModel;

public class CategoriaManagerFragment extends Fragment {
    private CategoriaSpesaViewModel mCategoriaViewModel;
    private CategoriaManagerViewModel managerViewModel;
    private RecyclerView mRecyclerView;
    private CategoriaSpesaListAdapter mAdapter;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_categoria_manager, container, false);

        mRecyclerView = view.findViewById(R.id.recyclerViewCategorie);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        FloatingActionButton fabAggiungiCategoria = view.findViewById(R.id.fabAggiungiCategoria);
        Button buttonShowEntrate = view.findViewById(R.id.buttonShowEntrate);
        Button buttonShowUscite = view.findViewById(R.id.buttonShowUscite);
        managerViewModel = new CategoriaManagerViewModel();
        mCategoriaViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication())).get(CategoriaSpesaViewModel.class);
        mAdapter = new CategoriaSpesaListAdapter(requireContext());
        mRecyclerView.setAdapter(mAdapter);

        observeCategorieFromFirebase();

        fabAggiungiCategoria.setOnClickListener(v -> mostraDialogAggiuntaCategoria());

        buttonShowEntrate.setOnClickListener(v -> filterCategorieByTipo("Entrata"));
        buttonShowUscite.setOnClickListener(v -> filterCategorieByTipo("Uscita"));

        mAdapter.setOnItemClickListener(new CategoriaSpesaListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(CategoriaSpesa categoria) {
                showDeleteCategoriaConfirmationDialog(categoria);
            }

            @Override
            public void onDeleteClick(CategoriaSpesa categoria) {
                showDeleteCategoriaConfirmationDialog(categoria);
            }

            @Override
            public void onSingleSelect(CategoriaSpesa categoria) {
                showDeleteCategoriaConfirmationDialog(categoria);
            }
        });

        return view;
    }

    private void observeCategorieFromFirebase() {
        managerViewModel.getCategorie().observe(getViewLifecycleOwner(), categorie -> {
            if (categorie != null) {
                mAdapter.setCategorie(categorie);
            } else {
                View view = getView();
                if (view != null) {
                    Snackbar.make(view, R.string.snackbar1, Snackbar.LENGTH_SHORT).show();
                }
            }
        });
    }


    private void filterCategorieByTipo(String tipo) {
        managerViewModel.getCategorie().observe(getViewLifecycleOwner(), categorie -> {
            List<CategoriaSpesa> filteredCategorie = categorie.stream()
                    .filter(categoria -> categoria.getTipo().equals(tipo))
                    .collect(Collectors.toList());
            mAdapter.setCategorie(filteredCategorie);
        });
    }

    private void showDeleteCategoriaConfirmationDialog(CategoriaSpesa categoria) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Conferma eliminazione")
                .setMessage("Sei sicuro di voler eliminare questa categoria?")
                .setPositiveButton("Conferma", (dialog, which) -> {
                    String tmp = categoria.getId();
                    managerViewModel.deleteCategoria(tmp);
                    mCategoriaViewModel.delete(tmp);
                    observeCategorieFromFirebase();
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    private void mostraDialogAggiuntaCategoria() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        View dialogView = requireActivity().getLayoutInflater().inflate(R.layout.dialog_aggiungi_categoria, null);

        final EditText editTextNomeCategoria = dialogView.findViewById(R.id.editTextNomeCategoria);
        final RadioGroup radioGroupTipoCategoria = dialogView.findViewById(R.id.radioGroupTipo);

        builder.setView(dialogView)
                .setTitle("Aggiungi Categoria")
                .setPositiveButton("Aggiungi", (dialog, which) -> {
                    String nomeCategoria = editTextNomeCategoria.getText().toString().trim();
                    String tipoCategoria = "";
                    int radioButtonId = radioGroupTipoCategoria.getCheckedRadioButtonId();
                    if (radioButtonId == R.id.radioButtonEntrata) {
                        tipoCategoria = "Entrata";
                    } else if (radioButtonId == R.id.radioButtonUscita) {
                        tipoCategoria = "Uscita";
                    }

                    if (!nomeCategoria.isEmpty() && radioButtonId != -1) {
                        CategoriaSpesa nuovaCategoria = new CategoriaSpesa(nomeCategoria, tipoCategoria);
                        managerViewModel.addCategoria(nuovaCategoria);
                        observeCategorieFromFirebase();
                    } else {
                        View view = getView();
                        if (view != null) {
                            Snackbar.make(view, R.string.snackbar2, Snackbar.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Annulla", null)
                .show();
    }
}
