package it.unimib.spendaciun.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import it.unimib.spendaciun.R;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;

public class CategoriaSpesaListAdapter extends RecyclerView.Adapter<CategoriaSpesaListAdapter.CategoriaSpesaViewHolder> {

    private final LayoutInflater mInflater;
    private List<CategoriaSpesa> mCategorie;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(CategoriaSpesa categoria);
        void onDeleteClick(CategoriaSpesa categoria);
        void onSingleSelect(CategoriaSpesa categoria);
    }


    public CategoriaSpesaListAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }


    class CategoriaSpesaViewHolder extends RecyclerView.ViewHolder {
        private final TextView nomeCategoriaTextView;
        private final ImageView iconaCategoriaImageView;

        public CategoriaSpesaViewHolder(View itemView) {
            super(itemView);
            nomeCategoriaTextView = itemView.findViewById(R.id.nomeCategoria);
            iconaCategoriaImageView = itemView.findViewById(R.id.iconaCategoria);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && mListener != null) {
                    CategoriaSpesa categoria = mCategorie.get(position);
                    mListener.onItemClick(categoria);
                }
            });


            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && mListener != null) {
                    CategoriaSpesa categoria = mCategorie.get(position);
                    mListener.onSingleSelect(categoria);
                }
            });

        }
    }

    @Override
    public CategoriaSpesaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_categoria_item, parent, false);
        return new CategoriaSpesaViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(CategoriaSpesaViewHolder holder, int position) {
        if (mCategorie != null) {
            CategoriaSpesa current = mCategorie.get(position);
            holder.nomeCategoriaTextView.setText(current.getNomeCategoria());
            String tmp = current.getTipo();
            String iconName = current.getIconName(tmp);
            int resourceId = holder.itemView.getContext().getResources().getIdentifier(iconName, "drawable", holder.itemView.getContext().getPackageName());
            holder.iconaCategoriaImageView.setImageResource(resourceId);
        } else {
            holder.nomeCategoriaTextView.setText("No Categoria");
        }
    }

    public void setCategorie(List<CategoriaSpesa> categorie) {
        mCategorie = new ArrayList<>(categorie);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mCategorie != null ? mCategorie.size() : 0;
    }
}
