package it.unimib.spendaciun.ui.main.fragment.grafici;

import android.app.AlertDialog;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.util.Consumer;
import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.google.android.material.datepicker.MaterialDatePicker;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.databinding.FragmentGraficiBinding;

public class GraficiFragment extends Fragment {
    private FragmentGraficiBinding binding;
    private Button buttonRangeDate;
    private Button buttonCategorie;
    private Button buttonResetFiltri;
    private Date startDate;
    private Date endDate;
    private List<String> selectedCategories = new ArrayList<>();
    private boolean[] checkedItems;
    private TextView textViewBilancio;
    private TextView textViewEntrate;
    private TextView textViewUscite;
    private TextView textViewPeriodoSelezionato;
    private GraficiViewModel graficiViewModel;
    private String authId;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        graficiViewModel = new ViewModelProvider(this).get(GraficiViewModel.class);
        Log.d("GraficiFragment", "onCreateView started");

        authId = graficiViewModel.getAuth();
        binding = FragmentGraficiBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        initializeUI(root);

        LiveData<List<String>> categorieUsciteLiveData = graficiViewModel.getCategorieUtente(authId, "Uscita", selectedCategories, startDate, endDate);
        LiveData<List<String>> categorieEntrateLiveData = graficiViewModel.getCategorieUtente(authId, "Entrata", selectedCategories, startDate, endDate);

        categorieUsciteLiveData.observe(getViewLifecycleOwner(), uscite -> selectedCategories.addAll(uscite));
        categorieEntrateLiveData.observe(getViewLifecycleOwner(), entrate -> selectedCategories.addAll(entrate));

        buttonCategorie.setOnClickListener(v -> showCategoryDialog());

        buttonRangeDate.setOnClickListener(v -> {
            MaterialDatePicker<Pair<Long, Long>> picker = MaterialDatePicker.Builder.dateRangePicker().build();
            picker.addOnPositiveButtonClickListener(selection -> {
                Long startDateLong = selection.first;
                Long endDateLong = selection.second;

                startDate = new Date(startDateLong);
                endDate = new Date(endDateLong);
                if (startDate != null && endDate != null) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                    String periodoSelezionato = dateFormat.format(startDate) + " - " + dateFormat.format(endDate);
                    textViewPeriodoSelezionato.setText(periodoSelezionato);
                    updateFilters();
                }
                updateCharts();
            });
            picker.show(getParentFragmentManager(), picker.toString());
        });

        buttonResetFiltri.setOnClickListener(v -> {
            startDate = null;
            endDate = null;
            selectedCategories = new ArrayList<>();
            textViewPeriodoSelezionato.setText(" ");
            updateCharts();
            buttonResetFiltri.setVisibility(View.GONE);
        });

        PieChart pieChartUscite = binding.pieChartUscite;
        PieChart pieChartEntrate = binding.pieChartEntrate;
        BarChart barChart = binding.barChart;

        Button btnUscite = binding.buttonUscite;
        Button btnEntrate = binding.buttonEntrate;
        btnUscite.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_300, Resources.getSystem().newTheme()));

        initializePieChart(pieChartUscite, btnUscite, "Uscite:", categorieUsciteLiveData, graficiViewModel.getTotaleCategorie(authId, "Uscita", selectedCategories, startDate, endDate));

        initializePieChart(pieChartEntrate, btnEntrate, "Entrate:", categorieEntrateLiveData, graficiViewModel.getTotaleCategorie(authId, "Entrata", selectedCategories, startDate, endDate));

        initializeBarChart(barChart, graficiViewModel.getTotaleCategorie(authId, "Uscita", selectedCategories, startDate, endDate),
                graficiViewModel.getTotaleCategorie(authId, "Entrata", selectedCategories, startDate, endDate));

        graficiViewModel.getText().observe(getViewLifecycleOwner(), textViewBilancio::setText);

        return root;
    }

    private void initializeUI(View root) {
        textViewBilancio = root.findViewById(R.id.textViewBilancio);
        textViewEntrate =  root.findViewById(R.id.textViewEntrate);
        textViewUscite =  root.findViewById(R.id.textViewUscite);
        textViewPeriodoSelezionato = root.findViewById(R.id.textViewPeriodoSelezionato);
        buttonCategorie = root.findViewById(R.id.buttonCategorie);
        buttonRangeDate = root.findViewById(R.id.buttonRangeDate);
        buttonResetFiltri = root.findViewById(R.id.buttonResetFiltri);
    }

    private void updateFilters(){
        if (selectedCategories.isEmpty() && startDate == null && endDate == null) {
            buttonResetFiltri.setVisibility(View.GONE);
        } else {
            buttonResetFiltri.setVisibility(View.VISIBLE);
        }
    }

    private void updateCharts() {
        LiveData<List<String>> categorieUsciteLiveData = graficiViewModel.getCategorieUtente(authId, "Uscita", selectedCategories, startDate, endDate);
        LiveData<List<Float>> totaleUsciteLiveData = graficiViewModel.getTotaleCategorie(authId, "Uscita", selectedCategories, startDate, endDate);
        initializePieChart(binding.pieChartUscite, binding.buttonUscite, "Uscite:", categorieUsciteLiveData, totaleUsciteLiveData);

        LiveData<List<String>> categorieEntrateLiveData = graficiViewModel.getCategorieUtente(authId, "Entrata", selectedCategories, startDate, endDate);
        LiveData<List<Float>> totaleEntrateLiveData = graficiViewModel.getTotaleCategorie(authId, "Entrata", selectedCategories, startDate, endDate);
        initializePieChart(binding.pieChartEntrate, binding.buttonEntrate, "Entrate:", categorieEntrateLiveData, totaleEntrateLiveData);

        initializeBarChart(binding.barChart, totaleUsciteLiveData, totaleEntrateLiveData);

    }

    private void showCategoryDialog() {
        graficiViewModel.loadCategoriesFromFirebase(categories -> {
            checkedItems = new boolean[categories.size()];
            Arrays.fill(checkedItems, true);

            String[] categoriesArray = categories.toArray(new String[0]);

            selectedCategories = new ArrayList<>(categories);

            AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
            builder.setTitle("Scegli Categorie")
                    .setMultiChoiceItems(categoriesArray, checkedItems, (dialog, which, isChecked) -> {
                        checkedItems[which] = isChecked;
                    })
                    .setPositiveButton("OK", (dialog, which) -> {
                        selectedCategories.clear();
                        for (int i = 0; i < categoriesArray.length; i++) {
                            if (checkedItems[i]) {
                                selectedCategories.add(categoriesArray[i]);
                            }
                        }

                        Log.d("ShowCategoryDialog", "Selected Categories: " + selectedCategories.toString());
                        Log.d("ShowCategoryDialog", "Checked Items: " + Arrays.toString(checkedItems));

                        updateCharts();
                    })
                    .setNegativeButton("Annulla", null);

            AlertDialog dialog = builder.create();
            updateFilters();
            dialog.show();
        });
    }


    private void initializePieChart(PieChart pieChart, Button button, String centerText, LiveData<List<String>> categorieLiveData,
                                    LiveData<List<Float>> totaleLiveData) {
        categorieLiveData.observe(getViewLifecycleOwner(), categorie -> {

            totaleLiveData.observe(getViewLifecycleOwner(), totaleList -> {
                float bilancioTotale = 0f;

                if ((categorie == null || categorie.isEmpty()) || (totaleList == null || totaleList.isEmpty())) {
                    pieChart.clear();
                    pieChart.setNoDataText("Nessun dato disponibile");
                    pieChart.setVisibility(View.VISIBLE);
                    return;
                }

                if (categorie != null && totaleList != null && categorie.size() == totaleList.size()) {
                    for (Float totale : totaleList) {
                        bilancioTotale += totale;
                    }

                    List<PieEntry> entries = new ArrayList<>();
                    List<Integer> colors = new ArrayList<>();

                    int[] colorsArray = new int[]{
                            getResources().getColor(R.color.colorCategoria1, Resources.getSystem().newTheme()),
                            getResources().getColor(R.color.colorCategoria2, Resources.getSystem().newTheme()),
                            getResources().getColor(R.color.colorCategoria3, Resources.getSystem().newTheme()),
                            getResources().getColor(R.color.colorCategoria4, Resources.getSystem().newTheme()),
                            getResources().getColor(R.color.colorCategoria5, Resources.getSystem().newTheme()),
                            getResources().getColor(R.color.colorCategoria6, Resources.getSystem().newTheme()),
                            getResources().getColor(R.color.colorCategoria7, Resources.getSystem().newTheme()),
                            getResources().getColor(R.color.colorCategoria8, Resources.getSystem().newTheme())
                    };

                    for (int i = 0; i < categorie.size(); i++) {
                        float percentuale = (totaleList.get(i) / bilancioTotale) * 100f;

                        entries.add(new PieEntry(percentuale, categorie.get(i)));
                        colors.add(colorsArray[i]);
                    }

                    PieDataSet dataSet = new PieDataSet(entries, "Spese per categoria");
                    dataSet.setColors(colors);

                    PieData pieData = new PieData(dataSet);
                    pieChart.setData(pieData);
                    pieChart.invalidate();

                    String bilancioTotaleString = String.format("%.2f", bilancioTotale);

                    float finalBilancioTotale = bilancioTotale;
                    pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
                        @Override
                        public void onValueSelected(Entry e, Highlight h) {
                            if (e != null) {
                                int selectedIndex = (int) h.getX();
                                float bilancioCategoria = totaleList.get(selectedIndex);

                                float percentualeCategoria = (bilancioCategoria / finalBilancioTotale) * 100f;

                                String bilancioCategoriaString = String.format("%.2f", bilancioCategoria);
                                String percentualeCategoriaString = String.format("%.2f", percentualeCategoria);

                                pieChart.setCenterText(categorie.get(selectedIndex) + "\n" + bilancioCategoriaString + "€\n" + percentualeCategoriaString + "%");
                            }
                        }

                        @Override
                        public void onNothingSelected() {
                            pieChart.setCenterText(centerText + "\n" + bilancioTotaleString + "€");
                        }
                    });

                    pieChart.getDescription().setEnabled(false);
                    pieChart.setUsePercentValues(true);
                    pieChart.setEntryLabelTextSize(12f);
                    pieChart.setEntryLabelColor(getResources().getColor(R.color.black, Resources.getSystem().newTheme()));
                    pieChart.setCenterText(centerText + "\n" + bilancioTotaleString + "€");
                    pieChart.setCenterTextSize(16f);
                    pieChart.getLegend().setEnabled(false);

                    pieChart.invalidate();
                }
            });
        });
        button.setOnClickListener(v -> {
            pieChart.setVisibility(View.VISIBLE);
            if (pieChart == binding.pieChartUscite) {
                binding.pieChartEntrate.setVisibility(View.GONE);
            } else if (pieChart == binding.pieChartEntrate) {
                binding.pieChartUscite.setVisibility(View.GONE);
            }
            binding.buttonUscite.setBackgroundColor(getResources().getColor(android.R.color.transparent, Resources.getSystem().newTheme()));
            binding.buttonEntrate.setBackgroundColor(getResources().getColor(android.R.color.transparent, Resources.getSystem().newTheme()));
            button.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_300, Resources.getSystem().newTheme()));
        });
    }

    private void initializeBarChart(BarChart barChart, LiveData<List<Float>> totaleUsciteLiveData,
                                    LiveData<List<Float>> totaleEntrateLiveData) {
        totaleUsciteLiveData.observe(getViewLifecycleOwner(), totaleUsciteList -> {
            totaleEntrateLiveData.observe(getViewLifecycleOwner(), totaleEntrateList -> {
                if (totaleUsciteList == null || totaleEntrateList == null) {
                    return;
                }

                List<BarEntry> entries = new ArrayList<>();
                List<Integer> colors = new ArrayList<>();

                entries.add(new BarEntry(0, calcolaBilancioTotale(totaleUsciteList)));
                colors.add(getResources().getColor(R.color.colorUscite, Resources.getSystem().newTheme()));

                entries.add(new BarEntry(1, calcolaBilancioTotale(totaleEntrateList)));
                colors.add(getResources().getColor(R.color.colorEntrate, Resources.getSystem().newTheme()));

                BarDataSet dataSet = new BarDataSet(entries, "Bilancio");
                dataSet.setColors(colors);

                BarData barData = new BarData(dataSet);
                barData.setBarWidth(0.6f);

                barChart.setData(barData);
                barChart.invalidate();

                YAxis leftAxis = barChart.getAxisLeft();
                leftAxis.setValueFormatter(new ValueFormatter() {
                    @Override
                    public String getAxisLabel(float value, AxisBase axis) {
                        return String.format("%.1f€", value);
                    }
                });

                leftAxis.setAxisMinimum(0f);
                YAxis rightAxis = barChart.getAxisRight();
                rightAxis.setEnabled(false);

                XAxis xAxis = barChart.getXAxis();
                xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
                xAxis.setValueFormatter(new IndexAxisValueFormatter(new String[]{"Uscite", "Entrate"}));

                xAxis.setGranularity(1f);

                barChart.getDescription().setEnabled(false);
                barChart.getLegend().setEnabled(false);

                barChart.invalidate();

                float bilancioUscite = arrotondaDueCifreDecimali(calcolaBilancioTotale(totaleUsciteList));
                float bilancioEntrate = arrotondaDueCifreDecimali(calcolaBilancioTotale(totaleEntrateList));
                float bilancioTotale = arrotondaDueCifreDecimali(bilancioEntrate - calcolaBilancioTotale(totaleUsciteList));
                textViewUscite.setText("-" + bilancioUscite + "€");
                textViewEntrate.setText(bilancioEntrate + "€");
                textViewBilancio.setText(bilancioTotale + "€");
                if(bilancioTotale<0){
                textViewBilancio.setTextColor(getResources().getColor(R.color.colorUscite, Resources.getSystem().newTheme()));
                }else{
                    textViewBilancio.setTextColor(getResources().getColor(R.color.colorEntrate, Resources.getSystem().newTheme()));
                }
            });
        });
    }

    public static float arrotondaDueCifreDecimali(float valore) {
        BigDecimal bd = new BigDecimal(Float.toString(valore));
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        return bd.floatValue();
    }

    private float calcolaBilancioTotale(List<Float> totaleList) {
        float bilancioTotale = 0f;
        if (totaleList != null) {
            for (Float totale : totaleList) {
                bilancioTotale += totale;
            }
        }
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        String bilancioTotaleString = decimalFormat.format(bilancioTotale);
        bilancioTotaleString = bilancioTotaleString.replace(',', '.');

        return Float.parseFloat(bilancioTotaleString);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}