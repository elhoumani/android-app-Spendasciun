package it.unimib.spendaciun.ui.main.fragment.impostazioni.funzionalitàImpostazioni;

import android.app.Application;
import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import java.util.List;

import it.unimib.spendaciun.data.repository.crypto.CryptoRepository;
import it.unimib.spendaciun.model.crypto.Crypto;

public class CryptoViewModel extends ViewModel {

    private MutableLiveData<List<Crypto>> cryptoData = new MutableLiveData<>();
    private boolean isDataLoaded = false;
    private MutableLiveData<Boolean> loadCryptoDataTrigger = new MutableLiveData<>();
    private MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);


    public LiveData<Boolean> getLoadCryptoDataTrigger() {
        return loadCryptoDataTrigger;
    }

    private Context applicationContext;
    private CryptoRepository mRepo;

    public CryptoViewModel(Application application) {
        super();
        this.mRepo = new CryptoRepository();
        this.applicationContext = application.getApplicationContext();
    }
    public LiveData<List<Crypto>> getCryptoData() {
        return cryptoData;
    }

    public void loadCryptoDataIfNeeded() {
        if (!isDataLoaded) {
            loadCryptoData();
        }
    }

    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }


    public void loadCryptoData() {
        if (!isDataLoaded) {
            isLoading.postValue(true);
            new Thread(() -> {
                try {
                    List<Crypto> data = mRepo.getCryptoData(applicationContext);
                    cryptoData.postValue(data);
                    isLoading.postValue(false);
                } catch (Exception e) {
                    e.printStackTrace();
                    cryptoData.postValue(null);
                    isLoading.postValue(false);
                }
            }).start();
        }
    }


    @Override
    protected void onCleared() {
        super.onCleared();
    }

    public void onActivityResumed() {
        loadCryptoDataTrigger.setValue(true);
    }
}
