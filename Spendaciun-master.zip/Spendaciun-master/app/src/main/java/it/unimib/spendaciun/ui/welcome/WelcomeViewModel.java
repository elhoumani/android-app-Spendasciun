package it.unimib.spendaciun.ui.welcome;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Map;
import java.util.function.Consumer;

import it.unimib.spendaciun.data.repository.user.AuthCallback;
import it.unimib.spendaciun.data.repository.SharedPreferencesRepository;
import it.unimib.spendaciun.data.repository.categoria.CategoriaSpesaFirestoreRepository;
import it.unimib.spendaciun.data.repository.user.UserRepository;

public class WelcomeViewModel extends ViewModel {
    private SharedPreferencesRepository sharedRepository;
    private UserRepository mUserRepo;
    private CategoriaSpesaFirestoreRepository categoriaSpesaFirestoreRepository;
    private MutableLiveData<Boolean> loginSuccess = new MutableLiveData<>();
    private MutableLiveData<Boolean> registrationSuccess = new MutableLiveData<>();
    private MutableLiveData<Boolean> passwordResetSuccess = new MutableLiveData<>();
    private MutableLiveData<Exception> operationFailed = new MutableLiveData<>();
    private MutableLiveData<Boolean> isLoading = new MutableLiveData<>();

    public WelcomeViewModel(Context context) {
        try {
            this.sharedRepository = new SharedPreferencesRepository(context);
            this.mUserRepo = new UserRepository();
            this.categoriaSpesaFirestoreRepository = new CategoriaSpesaFirestoreRepository();
        } catch (GeneralSecurityException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    public LiveData<Boolean> getLoginSuccess() {
        return loginSuccess;
    }
    public LiveData<Boolean> getRegistrationSuccess() {
        return registrationSuccess;
    }
    public LiveData<Exception> getOperationFailed() {
        return operationFailed;
    }
    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public void saveCredentials(String email, String password) {
        if (getRememberMe()) {
            sharedRepository.saveCredentials(email, password);
        } else {
            sharedRepository.clearCredentials();
        }
    }

    public String getEmail() {
            return sharedRepository.getEmail();
    }

    public String[] getCredentials() {
        return new String[]{
                sharedRepository.getEmail(),
                sharedRepository.getPassword()
        };
    }

    public void setRememberMe(boolean rememberMe) {
        sharedRepository.setRememberMe(rememberMe);
    }

    public boolean getRememberMe() {
        return sharedRepository.getRememberMe();
    }

    public void loginUser(String email, String password) {
        mUserRepo.loginUser(email, password, new AuthCallback() {
            @Override
            public void onSuccess() {
                loginSuccess.postValue(true);
                saveCredentials(email, password);
            }
            @Override
            public void onFailure(Exception e) {
                operationFailed.postValue(e);
            }
        });
    }


    public void registerUser(final String name, final String email, final String password) {
        isLoading.setValue(true);
        mUserRepo.registerUser(name, email, password, success -> {
            isLoading.postValue(false);
            if (success) {
                addDefaultCategories();
                registrationSuccess.postValue(true);
            }
        }, failure -> {
            isLoading.postValue(false);
            operationFailed.postValue(failure);
        });
    }

    private void addDefaultCategories() {
        categoriaSpesaFirestoreRepository.addDefaultCategories();
    }

    public void resetUserPassword(String email) {
        mUserRepo.resetUserPassword(email, success -> {
            passwordResetSuccess.postValue(true);
        }, failure -> operationFailed.postValue(failure));
    }

    public void logoutUser() {
        mUserRepo.logoutUser();
        setRememberMe(false);
        sharedRepository.clearCredentials();
    }
}
