package it.unimib.spendaciun.util;

import android.widget.TextView;
import androidx.core.widget.TextViewCompat;

public class TextViewUtils {
    public static void setAutoSizeTextTypeWithDefaults(TextView textView, int autoSizeTextType) {
        TextViewCompat.setAutoSizeTextTypeWithDefaults(textView, autoSizeTextType);
    }

    public static void setAutoSizeTextTypeUniform(TextView textView) {
        setAutoSizeTextTypeWithDefaults(textView, TextViewCompat.AUTO_SIZE_TEXT_TYPE_UNIFORM);
    }
}
