package it.unimib.spendaciun.data.repository.crypto;

import android.content.Context;

import java.util.List;

import it.unimib.spendaciun.data.source.crypto.CoinGeckoDataSource;
import it.unimib.spendaciun.model.crypto.Crypto;

public class CryptoRepository {
    private CoinGeckoDataSource coinGeckoDataSource;
    public CryptoRepository(){
        coinGeckoDataSource = new CoinGeckoDataSource();
    }

    public List<Crypto> getCryptoData(Context applicationContext) {
        return coinGeckoDataSource.getCryptoData(applicationContext);
    }
}
