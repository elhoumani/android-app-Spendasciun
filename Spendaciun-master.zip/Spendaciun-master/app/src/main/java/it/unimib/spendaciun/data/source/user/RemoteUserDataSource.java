package it.unimib.spendaciun.data.source.user;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import it.unimib.spendaciun.data.repository.user.AuthCallback;

public class RemoteUserDataSource {
    private static final String TAG = "RemoteUserDataSource";
    private final FirebaseAuth auth;
    private final FirebaseFirestore db;
    private FirebaseUser currentUser;

    public RemoteUserDataSource() {
        this.auth = FirebaseAuth.getInstance();
        this.db = FirebaseFirestore.getInstance();
        currentUser = auth.getCurrentUser();
    }


    public void saveUserInformation(String name, String email) {
        Map<String, Object> userData = new HashMap<>();
        userData.put("name", name);
        userData.put("email", email);
        String userId = auth.getUid();

        db.collection("users").document(userId)
                .set(userData)
                .addOnSuccessListener(aVoid -> Log.d("FirestoreHelper", "Nome utente e email salvati su Firestore"))
                .addOnFailureListener(e -> Log.w("FirestoreHelper", "Errore nel salvare nome utente ed email su Firestore", e));
    }

    public void deleteUser(String userId) {
       db.collection("users").document(userId)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    deleteCurrentUserAccount();
                    Log.d("deleteUser", "DocumentSnapshot successfully deleted!");
                })
                .addOnFailureListener(e -> {
                    // Operazione fallita
                    Log.w("deleteUser", "Error deleting document", e);
                });
    }

    public void deleteCurrentUserAccount() {
        if (currentUser != null) {
            currentUser.delete();
        } else {
            Log.e("AccountDeletion", "No user logged in or user could not be retrieved.");
        }
    }



    public void updateUserName(String userId, String newName) {
        Map<String, Object> userData = new HashMap<>();
        userData.put("name", newName);

        db.collection("users").document(userId)
                .update(userData)
                .addOnSuccessListener(aVoid -> Log.d("FirestoreHelper", "Nome utente aggiornato su Firestore"))
                .addOnFailureListener(e -> Log.w("FirestoreHelper", "Errore nell'aggiornare il nome utente su Firestore", e));
    }

    public void loadUserInformation(String userId, Consumer<Map<String, Object>> onSuccess) {
        db.collection("users").document(userId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        onSuccess.accept(documentSnapshot.getData());
                    } else {
                        Log.d("FirestoreHelper", "Nessun dato utente trovato");
                    }
                })
                .addOnFailureListener(e -> Log.w("FirestoreHelper", "Errore nel caricare le informazioni utente da Firestore", e));
    }



    public void loginUser(String email, String password, AuthCallback callback) {
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Notifica il successo senza passare l'utente, poiché l'esempio iniziale non lo richiedeva
                        callback.onSuccess();
                    } else {
                        callback.onFailure(task.getException());
                    }
                });
    }



    public void registerUser(String name, String email, String password, Consumer<Boolean> onSuccess, Consumer<Exception> onFailure) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        saveUserInformation(name, email); // Considera di non salvare la password in chiaro
                        onSuccess.accept(true);
                    } else {
                        onFailure.accept(task.getException());
                    }
                });
    }

    public void resetUserPassword(String email, Consumer<Boolean> onSuccess, Consumer<Exception> onFailure) {
       auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        onSuccess.accept(true);
                    } else {
                        onFailure.accept(task.getException());
                    }
                });
    }

    public void logoutUser() {
        auth.getInstance().signOut();
    }


    public FirebaseUser getCurretUser(){
        return currentUser;
    }


}