package it.unimib.spendaciun.data.repository.spesa;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import com.google.firebase.auth.FirebaseAuth;

import it.unimib.spendaciun.data.database.spesa.SpesaDao;
import it.unimib.spendaciun.data.database.spesa.SpesaRoomDatabase;
import it.unimib.spendaciun.data.source.spesa.LocalSpesaDataSource;
import it.unimib.spendaciun.model.spesa.Spesa;

public class SpesaRepository {

    private static final String TAG = "SpesaRepository";
    private final SpesaDao mSpesaDao;
    private final LiveData<List<Spesa>> mAllSpese;
    private final LocalSpesaDataSource localSpesaDataSource;
    private final Executor executor;



    public SpesaRepository(Application application) {
        SpesaRoomDatabase db = SpesaRoomDatabase.getDatabase(application);
        mSpesaDao = db.spesaDao();
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        localSpesaDataSource = new LocalSpesaDataSource(mSpesaDao);

        mAllSpese = localSpesaDataSource.getSpeseUtente(userId);
        executor = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<Spesa>> getAllSpese() {
        return mAllSpese;
    }

    public void insert(Spesa spesa) {
        if (spesa.getId() == null) {
            spesa.setId(UUID.randomUUID().toString());
        }
        executor.execute(() -> localSpesaDataSource.insertSpesa(spesa));
    }

    public void delete(Spesa spesa) {
        executor.execute(() -> localSpesaDataSource.deleteSpesa(spesa));
    }

    public void deleteByUserId(String userId) {
        executor.execute(() -> localSpesaDataSource.deleteByUserId(userId));
    }

    public void deleteByItemId(String itemId) {
        executor.execute(() -> localSpesaDataSource.deleteByItemId(itemId));
    }

    public void deleteAll() {
        executor.execute(localSpesaDataSource::deleteAll);
    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException("Method isEmpty needs to be implemented.");
    }

}
