package it.unimib.spendaciun.ui.main.fragment.aggiungiSpesa;
import android.app.Application;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import it.unimib.spendaciun.R;
import it.unimib.spendaciun.data.repository.spesa.SpesaFirestoreRepository;
import it.unimib.spendaciun.databinding.FragmentAggiungispesaBinding;
import it.unimib.spendaciun.model.categoria.CategoriaSpesa;
import it.unimib.spendaciun.model.spesa.Spesa;
import it.unimib.spendaciun.model.spesa.SpesaViewModel;
import it.unimib.spendaciun.data.repository.spesa.SpesaRepository;
import it.unimib.spendaciun.util.dialog.CategorySelectDialogFragment;
import it.unimib.spendaciun.util.dialog.DatePickerFragment;

public class AggiungiSpesaFragment extends Fragment implements DatePickerFragment.OnDateSelectedListener {

    private FragmentAggiungispesaBinding binding;
    private Date mSelectedDate;
    private AggiungiSpesaViewModel mViewModel;
    private String selectedCategoria;
    private String selectedTipoCategoria;
    private DatePickerFragment datePickerFragment;
    private String userId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAggiungispesaBinding.inflate(inflater, container, false);
        View view = binding.getRoot();
        setupViews(view);
        mViewModel = new ViewModelProvider(this).get(AggiungiSpesaViewModel.class);
        userId = mViewModel.getCurrentAuth();
        return view;
    }

    private void setupViews(View view) {
        EditText mEditSpesaView = view.findViewById(R.id.edit_nome);
        EditText mEditImportoView = view.findViewById(R.id.edit_importo);
        Spinner mEditTipoSpesaView = view.findViewById(R.id.spinner_tipo);
        Button mSelectCategoriaButton = view.findViewById(R.id.button_select_categoria);
        mSelectCategoriaButton.setOnClickListener(v -> showCategorySelectDialog());

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.tipo_spesa, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mEditTipoSpesaView.setAdapter(adapter);
        mEditTipoSpesaView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedTipoCategoria = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        Button buttonSave = view.findViewById(R.id.button_save);
        buttonSave.setOnClickListener(view1 -> saveExpense(mEditSpesaView, mEditImportoView, mEditTipoSpesaView));

        Button buttonDate = view.findViewById(R.id.button_date);
        buttonDate.setOnClickListener(view12 -> {
            DialogFragment newFragment = new DatePickerFragment(this);
            newFragment.show(getParentFragmentManager(), "datePicker");

        });
    }

    private void showCategorySelectDialog() {
        CategorySelectDialogFragment dialog = new CategorySelectDialogFragment(userId, selectedTipoCategoria);
        dialog.setOnCategoriaSelectedListener(new CategorySelectDialogFragment.OnCategoriaSelectedListener() {
            @Override
            public void onCategoriaSelected(CategoriaSpesa categoria) {
                selectedCategoria = categoria.getNomeCategoria();
                EditText editSelectedCategoria = getView().findViewById(R.id.edit_selected_categoria);
                editSelectedCategoria.setText(selectedCategoria);
            }
        });
        dialog.show(getParentFragmentManager(), "categorySelect");
    }


    private void saveExpense(EditText mEditSpesaView, EditText mEditImportoView, Spinner mEditTipoSpesaView) {
        String nomeSpesa = mEditSpesaView.getText().toString();
        String importoSpesa = mEditImportoView.getText().toString();
        String tipoSpesa = mEditTipoSpesaView.getSelectedItem().toString();

        if (mSelectedDate == null || selectedCategoria == null || selectedCategoria.isEmpty()) {
            showSnack("Seleziona una data e una categoria");
            return;
        }

        if (!TextUtils.isEmpty(nomeSpesa) && !TextUtils.isEmpty(importoSpesa)) {
            Spesa newSpesa = new Spesa(null, nomeSpesa, Double.parseDouble(importoSpesa), mSelectedDate, selectedCategoria, tipoSpesa);
            mViewModel.addSpesa(newSpesa);
            showSnack("Spesa salvata con successo!");
            resetInputFields(mEditSpesaView, mEditImportoView, mEditTipoSpesaView);
        } else {
            showSnack("Inserisci una spesa e un importo!");
        }
    }

    private void resetInputFields(EditText mEditSpesaView, EditText mEditImportoView, Spinner mEditTipoSpesaView) {
        mEditSpesaView.setText("");
        mEditImportoView.setText("");
        mEditTipoSpesaView.setSelection(0);

        EditText editSelectedCategoria = getView().findViewById(R.id.edit_selected_categoria);
        editSelectedCategoria.setText("");

        EditText editDate = getView().findViewById(R.id.edit_date);
        editDate.setText("");

        mSelectedDate = null;
        selectedCategoria = null;
    }


    private void showSnack(String message) {
        Snackbar.make(getView(), message, Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void onDateSelected(Date selectedDate) {
        mSelectedDate = selectedDate;

        EditText editDate = getView().findViewById(R.id.edit_date);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String formattedDate = dateFormat.format(mSelectedDate);
        editDate.setText(formattedDate);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        datePickerFragment = null;
        binding = null;
    }



}
