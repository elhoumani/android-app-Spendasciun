Progetto Programmazione Dispositivi Mobili
Università degli Studi di Milano - Bicocca
Anno Accademico 2023/2024

Gruppo:"RRRE"
Componenti del gruppo:
887970 Daniele Giorgio Michele Romano
886495 Lorenzo Radaelli
886158 Federica Ratti
869964 Ayoub El Houmani